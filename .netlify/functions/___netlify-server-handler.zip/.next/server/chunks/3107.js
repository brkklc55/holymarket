exports.id=3107,exports.ids=[3107],exports.modules={3615:(a,b)=>{let c,d=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];b.getSymbolSize=function(a){if(!a)throw Error('"version" cannot be null or undefined');if(a<1||a>40)throw Error('"version" should be in range from 1 to 40');return 4*a+17},b.getSymbolTotalCodewords=function(a){return d[a]},b.getBCHDigit=function(a){let b=0;for(;0!==a;)b++,a>>>=1;return b},b.setToSJISFunction=function(a){if("function"!=typeof a)throw Error('"toSJISFunc" is not a valid function.');c=a},b.isKanjiModeEnabled=function(){return void 0!==c},b.toSJIS=function(a){return c(a)}},6334:(a,b,c)=>{let d=c(51631);function e(a){this.mode=d.NUMERIC,this.data=a.toString()}e.getBitsLength=function(a){return 10*Math.floor(a/3)+(a%3?a%3*3+1:0)},e.prototype.getLength=function(){return this.data.length},e.prototype.getBitsLength=function(){return e.getBitsLength(this.data.length)},e.prototype.write=function(a){let b,c;for(b=0;b+3<=this.data.length;b+=3)c=parseInt(this.data.substr(b,3),10),a.put(c,10);let d=this.data.length-b;d>0&&(c=parseInt(this.data.substr(b),10),a.put(c,3*d+1))},a.exports=e},6885:(a,b,c)=>{let d=c(65966),e=c(93326),f=c(94161),g=c(11103),h=c(83340),i=c(65276);function j(a,b,c){if(void 0===a)throw Error("String required as first argument");if(void 0===c&&(c=b,b={}),"function"!=typeof c)if(d())b=c||{},c=null;else throw Error("Callback required as last argument");return{opts:b,cb:c}}function k(a){switch(a){case"svg":return i;case"txt":case"utf8":return g;default:return f}}function l(a,b,c){if(!c.cb)return new Promise(function(d,f){try{let g=e.create(b,c.opts);return a(g,c.opts,function(a,b){return a?f(a):d(b)})}catch(a){f(a)}});try{let d=e.create(b,c.opts);return a(d,c.opts,c.cb)}catch(a){c.cb(a)}}b.create=e.create,b.toCanvas=c(23548).toCanvas,b.toString=function(a,b,c){let d=j(a,b,c);return l(function(a){switch(a){case"svg":return i;case"terminal":return h;default:return g}}(d.opts?d.opts.type:void 0).render,a,d)},b.toDataURL=function(a,b,c){let d=j(a,b,c);return l(k(d.opts.type).renderToDataURL,a,d)},b.toBuffer=function(a,b,c){let d=j(a,b,c);return l(k(d.opts.type).renderToBuffer,a,d)},b.toFile=function(a,b,c,e){if("string"!=typeof a||"string"!=typeof b&&"object"!=typeof b)throw Error("Invalid argument");if(arguments.length<3&&!d())throw Error("Too few arguments provided");let f=j(b,c,e);return l(k(f.opts.type||a.slice((a.lastIndexOf(".")-1>>>0)+2).toLowerCase()).renderToFile.bind(null,a),b,f)},b.toFileStream=function(a,b,c){if(arguments.length<2)throw Error("Too few arguments provided");let d=j(b,c,a.emit.bind(a,"error"));l(k("png").renderToFileStream.bind(null,a),b,d)}},7098:(a,b,c)=>{let d=c(51631),e=c(3615);function f(a){this.mode=d.KANJI,this.data=a}f.getBitsLength=function(a){return 13*a},f.prototype.getLength=function(){return this.data.length},f.prototype.getBitsLength=function(){return f.getBitsLength(this.data.length)},f.prototype.write=function(a){let b;for(b=0;b<this.data.length;b++){let c=e.toSJIS(this.data[b]);if(c>=33088&&c<=40956)c-=33088;else if(c>=57408&&c<=60351)c-=49472;else throw Error("Invalid SJIS character: "+this.data[b]+"\nMake sure your charset is UTF-8");c=(c>>>8&255)*192+(255&c),a.put(c,13)}},a.exports=f},9353:(a,b,c)=>{let d=c(99127);function e(a,b){let c=a.a/255,d=b+'="'+a.hex+'"';return c<1?d+" "+b+'-opacity="'+c.toFixed(2).slice(1)+'"':d}function f(a,b,c){let d=a+b;return void 0!==c&&(d+=" "+c),d}b.render=function(a,b,c){let g=d.getOptions(b),h=a.modules.size,i=a.modules.data,j=h+2*g.margin,k=g.color.light.a?"<path "+e(g.color.light,"fill")+' d="M0 0h'+j+"v"+j+'H0z"/>':"",l="<path "+e(g.color.dark,"stroke")+' d="'+function(a,b,c){let d="",e=0,g=!1,h=0;for(let i=0;i<a.length;i++){let j=Math.floor(i%b),k=Math.floor(i/b);j||g||(g=!0),a[i]?(h++,i>0&&j>0&&a[i-1]||(d+=g?f("M",j+c,.5+k+c):f("m",e,0),e=0,g=!1),j+1<b&&a[i+1]||(d+=f("h",h),h=0)):e++}return d}(i,h,g.margin)+'"/>',m='<svg xmlns="http://www.w3.org/2000/svg" '+(g.width?'width="'+g.width+'" height="'+g.width+'" ':"")+('viewBox="0 0 '+j+" ")+j+'" shape-rendering="crispEdges">'+k+l+"</svg>\n";return"function"==typeof c&&c(null,m),m}},9709:(a,b,c)=>{"use strict";let d=!0,e=c(74075),f=c(80183);e.deflateSync||(d=!1);let g=c(81769),h=c(42516),i=c(96277),j=c(92858),k=c(83670);a.exports=function(a,b){let c,l,m,n;if(!d)throw Error("To use the sync capability of this library in old node versions, please pin pngjs to v2.3.0");let o=[],p=new g(a);if(new i(b,{read:p.read.bind(p),error:function(a){c=a},metadata:function(a){l=a},gamma:function(a){m=a},palette:function(a){l.palette=a},transColor:function(a){l.transColor=a},inflateData:function(a){o.push(a)},simpleTransparency:function(){l.alpha=!0}}).start(),p.process(),c)throw c;let q=Buffer.concat(o);if(o.length=0,l.interlace)n=e.inflateSync(q);else{let a=((l.width*l.bpp*l.depth+7>>3)+1)*l.height;n=f(q,{chunkSize:a,maxLength:a})}if(q=null,!n||!n.length)throw Error("bad png - invalid inflate data response");let r=h.process(n,l);q=null;let s=j.dataToBitMap(r,l);r=null;let t=k(s,l);return l.data=t,l.gamma=m||0,l}},11103:(a,b,c)=>{let d=c(99127),e={WW:" ",WB:"▄",BB:"█",BW:"▀"},f={BB:" ",BW:"▄",WW:"█",WB:"▀"};b.render=function(a,b,c){let g=d.getOptions(b),h=e;("#ffffff"===g.color.dark.hex||"#000000"===g.color.light.hex)&&(h=f);let i=a.modules.size,j=a.modules.data,k="",l=Array(i+2*g.margin+1).join(h.WW);l=Array(g.margin/2+1).join(l+"\n");let m=Array(g.margin+1).join(h.WW);k+=l;for(let a=0;a<i;a+=2){k+=m;for(let b=0;b<i;b++){var n;let c=j[a*i+b],d=j[(a+1)*i+b];k+=(n=h,c&&d?n.BB:c&&!d?n.BW:!c&&d?n.WB:n.WW)}k+=m+"\n"}return k+=l.slice(0,-1),"function"==typeof c&&c(null,k),k},b.renderToFile=function(a,d,e,f){void 0===f&&(f=e,e=void 0);let g=c(29021),h=b.render(d,e);g.writeFile(a,h,f)}},11884:a=>{function b(){this.buffer=[],this.length=0}b.prototype={get:function(a){let b=Math.floor(a/8);return(this.buffer[b]>>>7-a%8&1)==1},put:function(a,b){for(let c=0;c<b;c++)this.putBit((a>>>b-c-1&1)==1)},getLengthInBits:function(){return this.length},putBit:function(a){let b=Math.floor(this.length/8);this.buffer.length<=b&&this.buffer.push(0),a&&(this.buffer[b]|=128>>>this.length%8),this.length++}},a.exports=b},14335:(a,b)=>{b.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};b.isValid=function(a){return null!=a&&""!==a&&!isNaN(a)&&a>=0&&a<=7},b.from=function(a){return b.isValid(a)?parseInt(a,10):void 0},b.getPenaltyN1=function(a){let b=a.size,c=0,d=0,e=0,f=null,g=null;for(let h=0;h<b;h++){d=e=0,f=g=null;for(let i=0;i<b;i++){let b=a.get(h,i);b===f?d++:(d>=5&&(c+=3+(d-5)),f=b,d=1),(b=a.get(i,h))===g?e++:(e>=5&&(c+=3+(e-5)),g=b,e=1)}d>=5&&(c+=3+(d-5)),e>=5&&(c+=3+(e-5))}return c},b.getPenaltyN2=function(a){let b=a.size,c=0;for(let d=0;d<b-1;d++)for(let e=0;e<b-1;e++){let b=a.get(d,e)+a.get(d,e+1)+a.get(d+1,e)+a.get(d+1,e+1);(4===b||0===b)&&c++}return 3*c},b.getPenaltyN3=function(a){let b=a.size,c=0,d=0,e=0;for(let f=0;f<b;f++){d=e=0;for(let g=0;g<b;g++)d=d<<1&2047|a.get(f,g),g>=10&&(1488===d||93===d)&&c++,e=e<<1&2047|a.get(g,f),g>=10&&(1488===e||93===e)&&c++}return 40*c},b.getPenaltyN4=function(a){let b=0,c=a.data.length;for(let d=0;d<c;d++)b+=a.data[d];return 10*Math.abs(Math.ceil(100*b/c/5)-10)},b.applyMask=function(a,c){let d=c.size;for(let e=0;e<d;e++)for(let f=0;f<d;f++)c.isReserved(f,e)||c.xor(f,e,function(a,c,d){switch(a){case b.Patterns.PATTERN000:return(c+d)%2==0;case b.Patterns.PATTERN001:return c%2==0;case b.Patterns.PATTERN010:return d%3==0;case b.Patterns.PATTERN011:return(c+d)%3==0;case b.Patterns.PATTERN100:return(Math.floor(c/2)+Math.floor(d/3))%2==0;case b.Patterns.PATTERN101:return c*d%2+c*d%3==0;case b.Patterns.PATTERN110:return(c*d%2+c*d%3)%2==0;case b.Patterns.PATTERN111:return(c*d%3+(c+d)%2)%2==0;default:throw Error("bad maskPattern:"+a)}}(a,f,e))},b.getBestMask=function(a,c){let d=Object.keys(b.Patterns).length,e=0,f=1/0;for(let g=0;g<d;g++){c(g),b.applyMask(g,a);let d=b.getPenaltyN1(a)+b.getPenaltyN2(a)+b.getPenaltyN3(a)+b.getPenaltyN4(a);b.applyMask(g,a),d<f&&(f=d,e=g)}return e}},16419:(a,b,c)=>{let d=c(24566),e=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],f=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];b.getBlocksCount=function(a,b){switch(b){case d.L:return e[(a-1)*4+0];case d.M:return e[(a-1)*4+1];case d.Q:return e[(a-1)*4+2];case d.H:return e[(a-1)*4+3];default:return}},b.getTotalCodewordsCount=function(a,b){switch(b){case d.L:return f[(a-1)*4+0];case d.M:return f[(a-1)*4+1];case d.Q:return f[(a-1)*4+2];case d.H:return f[(a-1)*4+3];default:return}}},23107:(a,b,c)=>{"use strict";c.r(b),c.d(b,{W3mAllWalletsView:()=>bk,W3mConnectingWcBasicView:()=>aB,W3mDownloadsView:()=>bo});var d=c(53478),e=c(75705),f=c(63860),g=c(5645),h=c(50207),i=c(80066),j=c(18448);c(64436);var k=c(42353),l=c(33198),m=c(89608),n=c(89764),o=c(85126),p=c(62970);c(69970);var q=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let r=class extends d.WF{constructor(){super(),this.unsubscribe=[],this.tabIdx=void 0,this.connectors=m.a.state.connectors,this.count=h.N.state.count,this.filteredCount=h.N.state.filteredWallets.length,this.isFetchingRecommendedWallets=h.N.state.isFetchingRecommendedWallets,this.unsubscribe.push(m.a.subscribeKey("connectors",a=>this.connectors=a),h.N.subscribeKey("count",a=>this.count=a),h.N.subscribeKey("filteredWallets",a=>this.filteredCount=a.length),h.N.subscribeKey("isFetchingRecommendedWallets",a=>this.isFetchingRecommendedWallets=a))}disconnectedCallback(){this.unsubscribe.forEach(a=>a())}render(){let a=this.connectors.find(a=>"walletConnect"===a.id),{allWallets:b}=g.H.state;if(!a||"HIDE"===b||"ONLY_MOBILE"===b&&!f.w.isMobile())return null;let c=h.N.state.featured.length,e=this.count+c,i=e<10?e:10*Math.floor(e/10),j=this.filteredCount>0?this.filteredCount:i,m=`${j}`;this.filteredCount>0?m=`${this.filteredCount}`:j<e&&(m=`${j}+`);let o=n.x.hasAnyConnection(l.o.CONNECTOR_ID.WALLET_CONNECT);return(0,d.qy)`
      <wui-list-wallet
        name="Search Wallet"
        walletIcon="search"
        showAllWallets
        @click=${this.onAllWallets.bind(this)}
        tagLabel=${m}
        tagVariant="info"
        data-testid="all-wallets"
        tabIdx=${(0,k.J)(this.tabIdx)}
        .loading=${this.isFetchingRecommendedWallets}
        ?disabled=${o}
        size="sm"
      ></wui-list-wallet>
    `}onAllWallets(){o.E.sendEvent({type:"track",event:"CLICK_ALL_WALLETS"}),p.I.push("AllWallets",{redirectView:p.I.state.data?.redirectView})}};q([(0,e.MZ)()],r.prototype,"tabIdx",void 0),q([(0,e.wk)()],r.prototype,"connectors",void 0),q([(0,e.wk)()],r.prototype,"count",void 0),q([(0,e.wk)()],r.prototype,"filteredCount",void 0),q([(0,e.wk)()],r.prototype,"isFetchingRecommendedWallets",void 0),r=q([(0,j.EM)("w3m-all-wallets-widget")],r);var s=c(58319),t=c(78743),u=c(28020),v=c(56270);let w=(0,j.AH)`
  :host {
    margin-top: ${({spacing:a})=>a["1"]};
  }
  wui-separator {
    margin: ${({spacing:a})=>a["3"]} calc(${({spacing:a})=>a["3"]} * -1)
      ${({spacing:a})=>a["2"]} calc(${({spacing:a})=>a["3"]} * -1);
    width: calc(100% + ${({spacing:a})=>a["3"]} * 2);
  }
`;var x=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let y=class extends d.WF{constructor(){super(),this.unsubscribe=[],this.connectors=m.a.state.connectors,this.recommended=h.N.state.recommended,this.featured=h.N.state.featured,this.explorerWallets=h.N.state.explorerWallets,this.connections=n.x.state.connections,this.connectorImages=s.j.state.connectorImages,this.loadingTelegram=!1,this.unsubscribe.push(m.a.subscribeKey("connectors",a=>this.connectors=a),n.x.subscribeKey("connections",a=>this.connections=a),s.j.subscribeKey("connectorImages",a=>this.connectorImages=a),h.N.subscribeKey("recommended",a=>this.recommended=a),h.N.subscribeKey("featured",a=>this.featured=a),h.N.subscribeKey("explorerFilteredWallets",a=>{this.explorerWallets=a?.length?a:h.N.state.explorerWallets}),h.N.subscribeKey("explorerWallets",a=>{this.explorerWallets?.length||(this.explorerWallets=a)})),f.w.isTelegram()&&f.w.isIos()&&(this.loadingTelegram=!n.x.state.wcUri,this.unsubscribe.push(n.x.subscribeKey("wcUri",a=>this.loadingTelegram=!a)))}disconnectedCallback(){this.unsubscribe.forEach(a=>a())}render(){return(0,d.qy)`
      <wui-flex flexDirection="column" gap="2"> ${this.connectorListTemplate()} </wui-flex>
    `}mapConnectorsToExplorerWallets(a,b){return a.map(a=>{if("MULTI_CHAIN"===a.type&&a.connectors){let c=a.connectors.map(a=>a.id),d=a.connectors.map(a=>a.name),e=a.connectors.map(a=>a.info?.rdns);return a.explorerWallet=b?.find(a=>c.includes(a.id)||d.includes(a.name)||a.rdns&&(e.includes(a.rdns)||c.includes(a.rdns)))??a.explorerWallet,a}let c=b?.find(b=>b.id===a.id||b.rdns===a.info?.rdns||b.name===a.name);return a.explorerWallet=c??a.explorerWallet,a})}processConnectorsByType(a,b=!0){let c=v.g.sortConnectorsByExplorerWallet([...a]);return b?c.filter(v.g.showConnector):c}connectorListTemplate(){let a=this.mapConnectorsToExplorerWallets(this.connectors,this.explorerWallets??[]),b=v.g.getConnectorsByType(a,this.recommended,this.featured),c=this.processConnectorsByType(b.announced.filter(a=>"walletConnect"!==a.id)),d=this.processConnectorsByType(b.injected),e=this.processConnectorsByType(b.multiChain.filter(a=>"WalletConnect"!==a.name),!1),g=b.custom,h=b.recent,i=this.processConnectorsByType(b.external.filter(a=>a.id!==l.o.CONNECTOR_ID.COINBASE_SDK)),j=b.recommended,k=b.featured,m=v.g.getConnectorTypeOrder({custom:g,recent:h,announced:c,injected:d,multiChain:e,recommended:j,featured:k,external:i}),n=this.connectors.find(a=>"walletConnect"===a.id),o=f.w.isMobile(),p=[];for(let a of m)switch(a){case"walletConnect":!o&&n&&p.push({kind:"connector",subtype:"walletConnect",connector:n});break;case"recent":v.g.getFilteredRecentWallets().forEach(a=>p.push({kind:"wallet",subtype:"recent",wallet:a}));break;case"injected":e.forEach(a=>p.push({kind:"connector",subtype:"multiChain",connector:a})),c.forEach(a=>p.push({kind:"connector",subtype:"announced",connector:a})),d.forEach(a=>p.push({kind:"connector",subtype:"injected",connector:a}));break;case"featured":k.forEach(a=>p.push({kind:"wallet",subtype:"featured",wallet:a}));break;case"custom":v.g.getFilteredCustomWallets(g??[]).forEach(a=>p.push({kind:"wallet",subtype:"custom",wallet:a}));break;case"external":i.forEach(a=>p.push({kind:"connector",subtype:"external",connector:a}));break;case"recommended":v.g.getCappedRecommendedWallets(j).forEach(a=>p.push({kind:"wallet",subtype:"recommended",wallet:a}));break;default:console.warn(`Unknown connector type: ${a}`)}return p.map((a,b)=>"connector"===a.kind?this.renderConnector(a,b):this.renderWallet(a,b))}renderConnector(a,b){let c,e,f=a.connector,g=t.$.getConnectorImage(f)||this.connectorImages[f?.imageId??""],h=(this.connections.get(f.chain)??[]).some(a=>u.y.isLowerCaseMatch(a.connectorId,f.id));"multiChain"===a.subtype?(c="multichain",e="info"):"walletConnect"===a.subtype?(c="qr code",e="accent"):"injected"===a.subtype||"announced"===a.subtype?(c=h?"connected":"installed",e=h?"info":"success"):(c=void 0,e=void 0);let i=n.x.hasAnyConnection(l.o.CONNECTOR_ID.WALLET_CONNECT),j=("walletConnect"===a.subtype||"external"===a.subtype)&&i;return(0,d.qy)`
      <w3m-list-wallet
        displayIndex=${b}
        imageSrc=${(0,k.J)(g)}
        .installed=${!0}
        name=${f.name??"Unknown"}
        .tagVariant=${e}
        tagLabel=${(0,k.J)(c)}
        data-testid=${`wallet-selector-${f.id.toLowerCase()}`}
        size="sm"
        @click=${()=>this.onClickConnector(a)}
        tabIdx=${(0,k.J)(this.tabIdx)}
        ?disabled=${j}
        rdnsId=${(0,k.J)(f.explorerWallet?.rdns||void 0)}
        walletRank=${(0,k.J)(f.explorerWallet?.order)}
      >
      </w3m-list-wallet>
    `}onClickConnector(a){let b=p.I.state.data?.redirectView;if("walletConnect"===a.subtype){m.a.setActiveConnector(a.connector),f.w.isMobile()?p.I.push("AllWallets"):p.I.push("ConnectingWalletConnect",{redirectView:b});return}if("multiChain"===a.subtype){m.a.setActiveConnector(a.connector),p.I.push("ConnectingMultiChain",{redirectView:b});return}if("injected"===a.subtype){m.a.setActiveConnector(a.connector),p.I.push("ConnectingExternal",{connector:a.connector,redirectView:b,wallet:a.connector.explorerWallet});return}if("announced"===a.subtype)return"walletConnect"===a.connector.id?void(f.w.isMobile()?p.I.push("AllWallets"):p.I.push("ConnectingWalletConnect",{redirectView:b})):(p.I.push("ConnectingExternal",{connector:a.connector,redirectView:b,wallet:a.connector.explorerWallet}),void 0);p.I.push("ConnectingExternal",{connector:a.connector,redirectView:b})}renderWallet(a,b){let c=a.wallet,e=t.$.getWalletImage(c),f=n.x.hasAnyConnection(l.o.CONNECTOR_ID.WALLET_CONNECT),g=this.loadingTelegram,h="recent"===a.subtype?"recent":void 0,i="recent"===a.subtype?"info":void 0;return(0,d.qy)`
      <w3m-list-wallet
        displayIndex=${b}
        imageSrc=${(0,k.J)(e)}
        name=${c.name??"Unknown"}
        @click=${()=>this.onClickWallet(a)}
        size="sm"
        data-testid=${`wallet-selector-${c.id}`}
        tabIdx=${(0,k.J)(this.tabIdx)}
        ?loading=${g}
        ?disabled=${f}
        rdnsId=${(0,k.J)(c.rdns||void 0)}
        walletRank=${(0,k.J)(c.order)}
        tagLabel=${(0,k.J)(h)}
        .tagVariant=${i}
      >
      </w3m-list-wallet>
    `}onClickWallet(a){let b=p.I.state.data?.redirectView;if("featured"===a.subtype)return void m.a.selectWalletConnector(a.wallet);if("recent"===a.subtype){if(this.loadingTelegram)return;m.a.selectWalletConnector(a.wallet);return}if("custom"===a.subtype){if(this.loadingTelegram)return;p.I.push("ConnectingWalletConnect",{wallet:a.wallet,redirectView:b});return}if(this.loadingTelegram)return;let c=m.a.getConnector({id:a.wallet.id,rdns:a.wallet.rdns});c?p.I.push("ConnectingExternal",{connector:c,redirectView:b}):p.I.push("ConnectingWalletConnect",{wallet:a.wallet,redirectView:b})}};y.styles=w,x([(0,e.MZ)({type:Number})],y.prototype,"tabIdx",void 0),x([(0,e.wk)()],y.prototype,"connectors",void 0),x([(0,e.wk)()],y.prototype,"recommended",void 0),x([(0,e.wk)()],y.prototype,"featured",void 0),x([(0,e.wk)()],y.prototype,"explorerWallets",void 0),x([(0,e.wk)()],y.prototype,"connections",void 0),x([(0,e.wk)()],y.prototype,"connectorImages",void 0),x([(0,e.wk)()],y.prototype,"loadingTelegram",void 0),y=x([(0,j.EM)("w3m-connector-list")],y);var z=c(80141),A=c(23412),B=c(99257),C=c(69869),D=c(90999),E=c(103),F=c(58003),G=c(33440);c(49263),c(61389);var H=c(38051);let I=(0,H.AH)`
  :host {
    flex: 1;
    height: 100%;
  }

  button {
    width: 100%;
    height: 100%;
    display: inline-flex;
    align-items: center;
    padding: ${({spacing:a})=>a[1]} ${({spacing:a})=>a[2]};
    column-gap: ${({spacing:a})=>a[1]};
    color: ${({tokens:a})=>a.theme.textSecondary};
    border-radius: ${({borderRadius:a})=>a[20]};
    background-color: transparent;
    transition: background-color ${({durations:a})=>a.lg}
      ${({easings:a})=>a["ease-out-power-2"]};
    will-change: background-color;
  }

  /* -- Hover & Active states ----------------------------------------------------------- */
  button[data-active='true'] {
    color: ${({tokens:a})=>a.theme.textPrimary};
    background-color: ${({tokens:a})=>a.theme.foregroundTertiary};
  }

  button:hover:enabled:not([data-active='true']),
  button:active:enabled:not([data-active='true']) {
    wui-text,
    wui-icon {
      color: ${({tokens:a})=>a.theme.textPrimary};
    }
  }
`;var J=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let K={lg:"lg-regular",md:"md-regular",sm:"sm-regular"},L={lg:"md",md:"sm",sm:"sm"},M=class extends d.WF{constructor(){super(...arguments),this.icon="mobile",this.size="md",this.label="",this.active=!1}render(){return(0,d.qy)`
      <button data-active=${this.active}>
        ${this.icon?(0,d.qy)`<wui-icon size=${L[this.size]} name=${this.icon}></wui-icon>`:""}
        <wui-text variant=${K[this.size]}> ${this.label} </wui-text>
      </button>
    `}};M.styles=[F.W5,F.fD,I],J([(0,e.MZ)()],M.prototype,"icon",void 0),J([(0,e.MZ)()],M.prototype,"size",void 0),J([(0,e.MZ)()],M.prototype,"label",void 0),J([(0,e.MZ)({type:Boolean})],M.prototype,"active",void 0),M=J([(0,G.E)("wui-tab-item")],M);let N=(0,H.AH)`
  :host {
    display: inline-flex;
    align-items: center;
    background-color: ${({tokens:a})=>a.theme.foregroundSecondary};
    border-radius: ${({borderRadius:a})=>a[32]};
    padding: ${({spacing:a})=>a["01"]};
    box-sizing: border-box;
  }

  :host([data-size='sm']) {
    height: 26px;
  }

  :host([data-size='md']) {
    height: 36px;
  }
`;var O=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let P=class extends d.WF{constructor(){super(...arguments),this.tabs=[],this.onTabChange=()=>null,this.size="md",this.activeTab=0}render(){return this.dataset.size=this.size,this.tabs.map((a,b)=>{let c=b===this.activeTab;return(0,d.qy)`
        <wui-tab-item
          @click=${()=>this.onTabClick(b)}
          icon=${a.icon}
          size=${this.size}
          label=${a.label}
          ?active=${c}
          data-active=${c}
          data-testid="tab-${a.label?.toLowerCase()}"
        ></wui-tab-item>
      `})}onTabClick(a){this.activeTab=a,this.onTabChange(a)}};P.styles=[F.W5,F.fD,N],O([(0,e.MZ)({type:Array})],P.prototype,"tabs",void 0),O([(0,e.MZ)()],P.prototype,"onTabChange",void 0),O([(0,e.MZ)()],P.prototype,"size",void 0),O([(0,e.wk)()],P.prototype,"activeTab",void 0),P=O([(0,G.E)("wui-tabs")],P);var Q=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let R=class extends d.WF{constructor(){super(...arguments),this.platformTabs=[],this.unsubscribe=[],this.platforms=[],this.onSelectPlatfrom=void 0}disconnectCallback(){this.unsubscribe.forEach(a=>a())}render(){let a=this.generateTabs();return(0,d.qy)`
      <wui-flex justifyContent="center" .padding=${["0","0","4","0"]}>
        <wui-tabs .tabs=${a} .onTabChange=${this.onTabChange.bind(this)}></wui-tabs>
      </wui-flex>
    `}generateTabs(){let a=this.platforms.map(a=>{if("browser"===a)return{label:"Browser",icon:"extension",platform:"browser"};if("mobile"===a)return{label:"Mobile",icon:"mobile",platform:"mobile"};if("qrcode"===a)return{label:"Mobile",icon:"mobile",platform:"qrcode"};if("web"===a)return{label:"Webapp",icon:"browser",platform:"web"};if("desktop"===a)return{label:"Desktop",icon:"desktop",platform:"desktop"};return{label:"Browser",icon:"extension",platform:"unsupported"}});return this.platformTabs=a.map(({platform:a})=>a),a}onTabChange(a){let b=this.platformTabs[a];b&&this.onSelectPlatfrom?.(b)}};Q([(0,e.MZ)({type:Array})],R.prototype,"platforms",void 0),Q([(0,e.MZ)()],R.prototype,"onSelectPlatfrom",void 0),R=Q([(0,j.EM)("w3m-connecting-header")],R);var S=c(67090);c(85087),c(52958),c(42502),c(26838);let T=(0,H.AH)`
  :host {
    display: block;
    width: 100px;
    height: 100px;
  }

  svg {
    width: 100px;
    height: 100px;
  }

  rect {
    fill: none;
    stroke: ${a=>a.colors.accent100};
    stroke-width: 3px;
    stroke-linecap: round;
    animation: dash 1s linear infinite;
  }

  @keyframes dash {
    to {
      stroke-dashoffset: 0px;
    }
  }
`;var U=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let V=class extends d.WF{constructor(){super(...arguments),this.radius=36}render(){return this.svgLoaderTemplate()}svgLoaderTemplate(){let a=this.radius>50?50:this.radius,b=36-a;return(0,d.qy)`
      <svg viewBox="0 0 110 110" width="110" height="110">
        <rect
          x="2"
          y="2"
          width="106"
          height="106"
          rx=${a}
          stroke-dasharray="${116+b} ${245+b}"
          stroke-dashoffset=${360+1.75*b}
        />
      </svg>
    `}};V.styles=[F.W5,T],U([(0,e.MZ)({type:Number})],V.prototype,"radius",void 0),V=U([(0,G.E)("wui-loading-thumbnail")],V),c(82268),c(2094),c(41074),c(70669);let W=(0,H.AH)`
  wui-flex {
    width: 100%;
    height: 52px;
    box-sizing: border-box;
    background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    border-radius: ${({borderRadius:a})=>a[5]};
    padding-left: ${({spacing:a})=>a[3]};
    padding-right: ${({spacing:a})=>a[3]};
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${({spacing:a})=>a[6]};
  }

  wui-text {
    color: ${({tokens:a})=>a.theme.textSecondary};
  }

  wui-icon {
    width: 12px;
    height: 12px;
  }
`;var X=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let Y=class extends d.WF{constructor(){super(...arguments),this.disabled=!1,this.label="",this.buttonLabel=""}render(){return(0,d.qy)`
      <wui-flex justifyContent="space-between" alignItems="center">
        <wui-text variant="lg-regular" color="inherit">${this.label}</wui-text>
        <wui-button variant="accent-secondary" size="sm">
          ${this.buttonLabel}
          <wui-icon name="chevronRight" color="inherit" size="inherit" slot="iconRight"></wui-icon>
        </wui-button>
      </wui-flex>
    `}};Y.styles=[F.W5,F.fD,W],X([(0,e.MZ)({type:Boolean})],Y.prototype,"disabled",void 0),X([(0,e.MZ)()],Y.prototype,"label",void 0),X([(0,e.MZ)()],Y.prototype,"buttonLabel",void 0),Y=X([(0,G.E)("wui-cta-button")],Y);let Z=(0,j.AH)`
  :host {
    display: block;
    padding: 0 ${({spacing:a})=>a["5"]} ${({spacing:a})=>a["5"]};
  }
`;var $=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let _=class extends d.WF{constructor(){super(...arguments),this.wallet=void 0}render(){if(!this.wallet)return this.style.display="none",null;let{name:a,app_store:b,play_store:c,chrome_store:e,homepage:g}=this.wallet,h=f.w.isMobile(),i=f.w.isIos(),k=f.w.isAndroid(),l=[b,c,g,e].filter(Boolean).length>1,m=j.Zv.getTruncateString({string:a,charsStart:12,charsEnd:0,truncate:"end"});return l&&!h?(0,d.qy)`
        <wui-cta-button
          label=${`Don't have ${m}?`}
          buttonLabel="Get"
          @click=${()=>p.I.push("Downloads",{wallet:this.wallet})}
        ></wui-cta-button>
      `:!l&&g?(0,d.qy)`
        <wui-cta-button
          label=${`Don't have ${m}?`}
          buttonLabel="Get"
          @click=${this.onHomePage.bind(this)}
        ></wui-cta-button>
      `:b&&i?(0,d.qy)`
        <wui-cta-button
          label=${`Don't have ${m}?`}
          buttonLabel="Get"
          @click=${this.onAppStore.bind(this)}
        ></wui-cta-button>
      `:c&&k?(0,d.qy)`
        <wui-cta-button
          label=${`Don't have ${m}?`}
          buttonLabel="Get"
          @click=${this.onPlayStore.bind(this)}
        ></wui-cta-button>
      `:(this.style.display="none",null)}onAppStore(){this.wallet?.app_store&&f.w.openHref(this.wallet.app_store,"_blank")}onPlayStore(){this.wallet?.play_store&&f.w.openHref(this.wallet.play_store,"_blank")}onHomePage(){this.wallet?.homepage&&f.w.openHref(this.wallet.homepage,"_blank")}};_.styles=[Z],$([(0,e.MZ)({type:Object})],_.prototype,"wallet",void 0),_=$([(0,j.EM)("w3m-mobile-download-links")],_);let aa=(0,j.AH)`
  @keyframes shake {
    0% {
      transform: translateX(0);
    }
    25% {
      transform: translateX(3px);
    }
    50% {
      transform: translateX(-3px);
    }
    75% {
      transform: translateX(3px);
    }
    100% {
      transform: translateX(0);
    }
  }

  wui-flex:first-child:not(:only-child) {
    position: relative;
  }

  wui-wallet-image {
    width: 56px;
    height: 56px;
  }

  wui-loading-thumbnail {
    position: absolute;
  }

  wui-icon-box {
    position: absolute;
    right: calc(${({spacing:a})=>a["1"]} * -1);
    bottom: calc(${({spacing:a})=>a["1"]} * -1);
    opacity: 0;
    transform: scale(0.5);
    transition-property: opacity, transform;
    transition-duration: ${({durations:a})=>a.lg};
    transition-timing-function: ${({easings:a})=>a["ease-out-power-2"]};
    will-change: opacity, transform;
  }

  wui-text[align='center'] {
    width: 100%;
    padding: 0px ${({spacing:a})=>a["4"]};
  }

  [data-error='true'] wui-icon-box {
    opacity: 1;
    transform: scale(1);
  }

  [data-error='true'] > wui-flex:first-child {
    animation: shake 250ms ${({easings:a})=>a["ease-out-power-2"]} both;
  }

  [data-retry='false'] wui-link {
    display: none;
  }

  [data-retry='true'] wui-link {
    display: block;
    opacity: 1;
  }

  w3m-mobile-download-links {
    padding: 0px;
    width: 100%;
  }
`;var ab=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};class ac extends d.WF{constructor(){super(),this.wallet=p.I.state.data?.wallet,this.connector=p.I.state.data?.connector,this.timeout=void 0,this.secondaryBtnIcon="refresh",this.onConnect=void 0,this.onRender=void 0,this.onAutoConnect=void 0,this.isWalletConnect=!0,this.unsubscribe=[],this.imageSrc=t.$.getConnectorImage(this.connector)??t.$.getWalletImage(this.wallet),this.name=this.wallet?.name??this.connector?.name??"Wallet",this.isRetrying=!1,this.uri=n.x.state.wcUri,this.error=n.x.state.wcError,this.ready=!1,this.showRetry=!1,this.label=void 0,this.secondaryBtnLabel="Try again",this.secondaryLabel="Accept connection request in the wallet",this.isLoading=!1,this.isMobile=!1,this.onRetry=void 0,this.unsubscribe.push(n.x.subscribeKey("wcUri",a=>{this.uri=a,this.isRetrying&&this.onRetry&&(this.isRetrying=!1,this.onConnect?.())}),n.x.subscribeKey("wcError",a=>this.error=a)),(f.w.isTelegram()||f.w.isSafari())&&f.w.isIos()&&n.x.state.wcUri&&this.onConnect?.()}firstUpdated(){this.onAutoConnect?.(),this.showRetry=!this.onAutoConnect}disconnectedCallback(){this.unsubscribe.forEach(a=>a()),n.x.setWcError(!1),clearTimeout(this.timeout)}render(){this.onRender?.(),this.onShowRetry();let a=this.error?"Connection can be declined if a previous request is still active":this.secondaryLabel,b="";return this.label?b=this.label:(b=`Continue in ${this.name}`,this.error&&(b="Connection declined")),(0,d.qy)`
      <wui-flex
        data-error=${(0,k.J)(this.error)}
        data-retry=${this.showRetry}
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="6"
      >
        <wui-flex gap="2" justifyContent="center" alignItems="center">
          <wui-wallet-image size="lg" imageSrc=${(0,k.J)(this.imageSrc)}></wui-wallet-image>

          ${this.error?null:this.loaderTemplate()}

          <wui-icon-box
            color="error"
            icon="close"
            size="sm"
            border
            borderColor="wui-color-bg-125"
          ></wui-icon-box>
        </wui-flex>

        <wui-flex flexDirection="column" alignItems="center" gap="6"> <wui-flex
          flexDirection="column"
          alignItems="center"
          gap="2"
          .padding=${["2","0","0","0"]}
        >
          <wui-text align="center" variant="lg-medium" color=${this.error?"error":"primary"}>
            ${b}
          </wui-text>
          <wui-text align="center" variant="lg-regular" color="secondary">${a}</wui-text>
        </wui-flex>

        ${this.secondaryBtnLabel?(0,d.qy)`
                <wui-button
                  variant="neutral-secondary"
                  size="md"
                  ?disabled=${this.isRetrying||this.isLoading}
                  @click=${this.onTryAgain.bind(this)}
                  data-testid="w3m-connecting-widget-secondary-button"
                >
                  <wui-icon
                    color="inherit"
                    slot="iconLeft"
                    name=${this.secondaryBtnIcon}
                  ></wui-icon>
                  ${this.secondaryBtnLabel}
                </wui-button>
              `:null}
      </wui-flex>

      ${this.isWalletConnect?(0,d.qy)`
              <wui-flex .padding=${["0","5","5","5"]} justifyContent="center">
                <wui-link
                  @click=${this.onCopyUri}
                  variant="secondary"
                  icon="copy"
                  data-testid="wui-link-copy"
                >
                  Copy link
                </wui-link>
              </wui-flex>
            `:null}

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links></wui-flex>
      </wui-flex>
    `}onShowRetry(){if(this.error&&!this.showRetry){this.showRetry=!0;let a=this.shadowRoot?.querySelector("wui-button");a?.animate([{opacity:0},{opacity:1}],{fill:"forwards",easing:"ease"})}}onTryAgain(){n.x.setWcError(!1),this.onRetry?(this.isRetrying=!0,this.onRetry?.()):this.onConnect?.()}loaderTemplate(){let a=S.W.state.themeVariables["--w3m-border-radius-master"],b=a?parseInt(a.replace("px",""),10):4;return(0,d.qy)`<wui-loading-thumbnail radius=${9*b}></wui-loading-thumbnail>`}onCopyUri(){try{this.uri&&(f.w.copyToClopboard(this.uri),B.P.showSuccess("Link copied"))}catch{B.P.showError("Failed to copy")}}}ac.styles=aa,ab([(0,e.wk)()],ac.prototype,"isRetrying",void 0),ab([(0,e.wk)()],ac.prototype,"uri",void 0),ab([(0,e.wk)()],ac.prototype,"error",void 0),ab([(0,e.wk)()],ac.prototype,"ready",void 0),ab([(0,e.wk)()],ac.prototype,"showRetry",void 0),ab([(0,e.wk)()],ac.prototype,"label",void 0),ab([(0,e.wk)()],ac.prototype,"secondaryBtnLabel",void 0),ab([(0,e.wk)()],ac.prototype,"secondaryLabel",void 0),ab([(0,e.wk)()],ac.prototype,"isLoading",void 0),ab([(0,e.MZ)({type:Boolean})],ac.prototype,"isMobile",void 0),ab([(0,e.MZ)()],ac.prototype,"onRetry",void 0);let ad=class extends ac{constructor(){if(super(),!this.wallet)throw Error("w3m-connecting-wc-browser: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onAutoConnect=this.onConnectProxy.bind(this),o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:p.I.state.view}})}async onConnectProxy(){try{this.error=!1;let{connectors:a}=m.a.state,b=a.find(a=>"ANNOUNCED"===a.type&&a.info?.rdns===this.wallet?.rdns||"INJECTED"===a.type||a.name===this.wallet?.name);if(b)await n.x.connectExternal(b,b.chain);else throw Error("w3m-connecting-wc-browser: No connector found");C.W.close(),o.E.sendEvent({type:"track",event:"CONNECT_SUCCESS",properties:{method:"browser",name:this.wallet?.name||"Unknown",view:p.I.state.view,walletRank:this.wallet?.order}})}catch(a){a instanceof D.A&&a.originalName===z.RQ.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST?o.E.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:a.message}}):o.E.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:a?.message??"Unknown"}}),this.error=!0}}};ad=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g}([(0,j.EM)("w3m-connecting-wc-browser")],ad);let ae=class extends ac{constructor(){if(super(),!this.wallet)throw Error("w3m-connecting-wc-desktop: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.onRender=this.onRenderProxy.bind(this),o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"desktop",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:p.I.state.view}})}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onConnectProxy(){if(this.wallet?.desktop_link&&this.uri)try{this.error=!1;let{desktop_link:a,name:b}=this.wallet,{redirect:c,href:d}=f.w.formatNativeUrl(a,this.uri);n.x.setWcLinking({name:b,href:d}),n.x.setRecentWallet(this.wallet),f.w.openHref(c,"_blank")}catch{this.error=!0}}};ae=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g}([(0,j.EM)("w3m-connecting-wc-desktop")],ae);var af=c(72742),ag=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let ah=class extends ac{constructor(){if(super(),this.btnLabelTimeout=void 0,this.redirectDeeplink=void 0,this.redirectUniversalLink=void 0,this.target=void 0,this.preferUniversalLinks=g.H.state.experimental_preferUniversalLinks,this.isLoading=!0,this.onConnect=()=>{if(this.wallet?.mobile_link&&this.uri)try{this.error=!1;let{mobile_link:a,link_mode:b,name:c}=this.wallet,{redirect:d,redirectUniversalLink:e,href:g}=f.w.formatNativeUrl(a,this.uri,b);this.redirectDeeplink=d,this.redirectUniversalLink=e,this.target=f.w.isIframe()?"_top":"_self",n.x.setWcLinking({name:c,href:g}),n.x.setRecentWallet(this.wallet),this.preferUniversalLinks&&this.redirectUniversalLink?f.w.openHref(this.redirectUniversalLink,this.target):f.w.openHref(this.redirectDeeplink,this.target)}catch(a){o.E.sendEvent({type:"track",event:"CONNECT_PROXY_ERROR",properties:{message:a instanceof Error?a.message:"Error parsing the deeplink",uri:this.uri,mobile_link:this.wallet.mobile_link,name:this.wallet.name}}),this.error=!0}},!this.wallet)throw Error("w3m-connecting-wc-mobile: No wallet provided");this.secondaryBtnLabel="Open",this.secondaryLabel=af.oU.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.onHandleURI(),this.unsubscribe.push(n.x.subscribeKey("wcUri",()=>{this.onHandleURI()})),o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"mobile",displayIndex:this.wallet?.display_index,walletRank:this.wallet.order,view:p.I.state.view}})}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.btnLabelTimeout)}onHandleURI(){this.isLoading=!this.uri,!this.ready&&this.uri&&(this.ready=!0,this.onConnect?.())}onTryAgain(){n.x.setWcError(!1),this.onConnect?.()}};ag([(0,e.wk)()],ah.prototype,"redirectDeeplink",void 0),ag([(0,e.wk)()],ah.prototype,"redirectUniversalLink",void 0),ag([(0,e.wk)()],ah.prototype,"target",void 0),ag([(0,e.wk)()],ah.prototype,"preferUniversalLinks",void 0),ag([(0,e.wk)()],ah.prototype,"isLoading",void 0),ah=ag([(0,j.EM)("w3m-connecting-wc-mobile")],ah),c(87922);var ai=c(30104);function aj(a,b,c){return a!==b&&(a-b<0?b-a:a-b)<=c+.1}let ak={generate({uri:a,size:b,logoSize:c,padding:e=8,dotColor:f="var(--apkt-colors-black)"}){let g,h,i=[],j=(h=Math.sqrt((g=Array.prototype.slice.call(ai.create(a,{errorCorrectionLevel:"Q"}).modules.data,0)).length),g.reduce((a,b,c)=>(c%h==0?a.push([b]):a[a.length-1].push(b))&&a,[])),k=(b-2*e)/j.length,l=[{x:0,y:0},{x:1,y:0},{x:0,y:1}];l.forEach(({x:a,y:b})=>{let c=(j.length-7)*k*a+e,g=(j.length-7)*k*b+e;for(let a=0;a<l.length;a+=1){let b=k*(7-2*a);i.push((0,d.JW)`
            <rect
              fill=${2===a?"var(--apkt-colors-black)":"var(--apkt-colors-white)"}
              width=${0===a?b-10:b}
              rx= ${0===a?(b-10)*.45:.45*b}
              ry= ${0===a?(b-10)*.45:.45*b}
              stroke=${f}
              stroke-width=${10*(0===a)}
              height=${0===a?b-10:b}
              x= ${0===a?g+k*a+5:g+k*a}
              y= ${0===a?c+k*a+5:c+k*a}
            />
          `)}});let m=Math.floor((c+25)/k),n=j.length/2-m/2,o=j.length/2+m/2-1,p=[];j.forEach((a,b)=>{a.forEach((a,c)=>{!j[b][c]||b<7&&c<7||b>j.length-8&&c<7||b<7&&c>j.length-8||b>n&&b<o&&c>n&&c<o||p.push([b*k+k/2+e,c*k+k/2+e])})});let q={};return p.forEach(([a,b])=>{q[a]?q[a]?.push(b):q[a]=[b]}),Object.entries(q).map(([a,b])=>{let c=b.filter(a=>b.every(b=>!aj(a,b,k)));return[Number(a),c]}).forEach(([a,b])=>{b.forEach(b=>{i.push((0,d.JW)`<circle cx=${a} cy=${b} fill=${f} r=${k/2.5} />`)})}),Object.entries(q).filter(([a,b])=>b.length>1).map(([a,b])=>{let c=b.filter(a=>b.some(b=>aj(a,b,k)));return[Number(a),c]}).map(([a,b])=>{b.sort((a,b)=>a<b?-1:1);let c=[];for(let a of b){let b=c.find(b=>b.some(b=>aj(a,b,k)));b?b.push(a):c.push([a])}return[a,c.map(a=>[a[0],a[a.length-1]])]}).forEach(([a,b])=>{b.forEach(([b,c])=>{i.push((0,d.JW)`
              <line
                x1=${a}
                x2=${a}
                y1=${b}
                y2=${c}
                stroke=${f}
                stroke-width=${k/1.25}
                stroke-linecap="round"
              />
            `)})}),i}},al=(0,H.AH)`
  :host {
    position: relative;
    user-select: none;
    display: block;
    overflow: hidden;
    aspect-ratio: 1 / 1;
    width: 100%;
    height: 100%;
    background-color: ${({colors:a})=>a.white};
    border: 1px solid ${({tokens:a})=>a.theme.borderPrimary};
  }

  :host {
    border-radius: ${({borderRadius:a})=>a[4]};
    display: flex;
    align-items: center;
    justify-content: center;
  }

  :host([data-clear='true']) > wui-icon {
    display: none;
  }

  svg:first-child,
  wui-image,
  wui-icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateY(-50%) translateX(-50%);
    background-color: ${({tokens:a})=>a.theme.backgroundPrimary};
    box-shadow: inset 0 0 0 4px ${({tokens:a})=>a.theme.backgroundPrimary};
    border-radius: ${({borderRadius:a})=>a[6]};
  }

  wui-image {
    width: 25%;
    height: 25%;
    border-radius: ${({borderRadius:a})=>a[2]};
  }

  wui-icon {
    width: 100%;
    height: 100%;
    color: #3396ff !important;
    transform: translateY(-50%) translateX(-50%) scale(0.25);
  }

  wui-icon > svg {
    width: inherit;
    height: inherit;
  }
`;var am=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let an=class extends d.WF{constructor(){super(...arguments),this.uri="",this.size=500,this.theme="dark",this.imageSrc=void 0,this.alt=void 0,this.arenaClear=void 0,this.farcaster=void 0}render(){return this.dataset.theme=this.theme,this.dataset.clear=String(this.arenaClear),(0,d.qy)`<wui-flex
      alignItems="center"
      justifyContent="center"
      class="wui-qr-code"
      direction="column"
      gap="4"
      width="100%"
      style="height: 100%"
    >
      ${this.templateVisual()} ${this.templateSvg()}
    </wui-flex>`}templateSvg(){return(0,d.JW)`
      <svg viewBox="0 0 ${this.size} ${this.size}" width="100%" height="100%">
        ${ak.generate({uri:this.uri,size:this.size,logoSize:this.arenaClear?0:this.size/4})}
      </svg>
    `}templateVisual(){return this.imageSrc?(0,d.qy)`<wui-image src=${this.imageSrc} alt=${this.alt??"logo"}></wui-image>`:this.farcaster?(0,d.qy)`<wui-icon
        class="farcaster"
        size="inherit"
        color="inherit"
        name="farcaster"
      ></wui-icon>`:(0,d.qy)`<wui-icon size="inherit" color="inherit" name="walletConnect"></wui-icon>`}};an.styles=[F.W5,al],am([(0,e.MZ)()],an.prototype,"uri",void 0),am([(0,e.MZ)({type:Number})],an.prototype,"size",void 0),am([(0,e.MZ)()],an.prototype,"theme",void 0),am([(0,e.MZ)()],an.prototype,"imageSrc",void 0),am([(0,e.MZ)()],an.prototype,"alt",void 0),am([(0,e.MZ)({type:Boolean})],an.prototype,"arenaClear",void 0),am([(0,e.MZ)({type:Boolean})],an.prototype,"farcaster",void 0),an=am([(0,G.E)("wui-qr-code")],an);let ao=(0,H.AH)`
  :host {
    display: block;
    background: linear-gradient(
      90deg,
      ${({tokens:a})=>a.theme.foregroundSecondary} 0%,
      ${({tokens:a})=>a.theme.foregroundTertiary} 50%,
      ${({tokens:a})=>a.theme.foregroundSecondary} 100%
    );
    background-size: 200% 100%;
    animation: shimmer 1s ease-in-out infinite;
    border-radius: ${({borderRadius:a})=>a[2]};
  }

  :host([data-rounded='true']) {
    border-radius: ${({borderRadius:a})=>a[16]};
  }

  @keyframes shimmer {
    0% {
      background-position: 200% 0;
    }
    100% {
      background-position: -200% 0;
    }
  }
`;var ap=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aq=class extends d.WF{constructor(){super(...arguments),this.width="",this.height="",this.variant="default",this.rounded=!1}render(){return this.style.cssText=`
      width: ${this.width};
      height: ${this.height};
    `,this.dataset.rounded=this.rounded?"true":"false",(0,d.qy)`<slot></slot>`}};aq.styles=[ao],ap([(0,e.MZ)()],aq.prototype,"width",void 0),ap([(0,e.MZ)()],aq.prototype,"height",void 0),ap([(0,e.MZ)()],aq.prototype,"variant",void 0),ap([(0,e.MZ)({type:Boolean})],aq.prototype,"rounded",void 0),aq=ap([(0,G.E)("wui-shimmer")],aq),c(16152);let ar=(0,j.AH)`
  wui-shimmer {
    width: 100%;
    aspect-ratio: 1 / 1;
    border-radius: ${({borderRadius:a})=>a[4]};
  }

  wui-qr-code {
    opacity: 0;
    animation-duration: ${({durations:a})=>a.xl};
    animation-timing-function: ${({easings:a})=>a["ease-out-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`;var as=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let at=class extends ac{constructor(){super(),this.basic=!1}firstUpdated(){this.basic||o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet?.name??"WalletConnect",platform:"qrcode",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:p.I.state.view}})}disconnectedCallback(){super.disconnectedCallback(),this.unsubscribe?.forEach(a=>a())}render(){return this.onRenderProxy(),(0,d.qy)`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["0","5","5","5"]}
        gap="5"
      >
        <wui-shimmer width="100%"> ${this.qrCodeTemplate()} </wui-shimmer>
        <wui-text variant="lg-medium" color="primary"> Scan this QR Code with your phone </wui-text>
        ${this.copyTemplate()}
      </wui-flex>
      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}onRenderProxy(){!this.ready&&this.uri&&(this.ready=!0)}qrCodeTemplate(){if(!this.uri||!this.ready)return null;let a=this.wallet?this.wallet.name:void 0;return n.x.setWcLinking(void 0),n.x.setRecentWallet(this.wallet),(0,d.qy)` <wui-qr-code
      theme=${S.W.state.themeMode}
      uri=${this.uri}
      imageSrc=${(0,k.J)(t.$.getWalletImage(this.wallet))}
      color=${(0,k.J)(S.W.state.themeVariables["--w3m-qr-color"])}
      alt=${(0,k.J)(a)}
      data-testid="wui-qr-code"
    ></wui-qr-code>`}copyTemplate(){let a=!this.uri||!this.ready;return(0,d.qy)`<wui-button
      .disabled=${a}
      @click=${this.onCopyUri}
      variant="neutral-secondary"
      size="sm"
      data-testid="copy-wc2-uri"
    >
      Copy link
      <wui-icon size="sm" color="inherit" name="copy" slot="iconRight"></wui-icon>
    </wui-button>`}};at.styles=ar,as([(0,e.MZ)({type:Boolean})],at.prototype,"basic",void 0),at=as([(0,j.EM)("w3m-connecting-wc-qrcode")],at);let au=class extends d.WF{constructor(){if(super(),this.wallet=p.I.state.data?.wallet,!this.wallet)throw Error("w3m-connecting-wc-unsupported: No wallet provided");o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"browser",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:p.I.state.view}})}render(){return(0,d.qy)`
      <wui-flex
        flexDirection="column"
        alignItems="center"
        .padding=${["10","5","5","5"]}
        gap="5"
      >
        <wui-wallet-image
          size="lg"
          imageSrc=${(0,k.J)(t.$.getWalletImage(this.wallet))}
        ></wui-wallet-image>

        <wui-text variant="md-regular" color="primary">Not Detected</wui-text>
      </wui-flex>

      <w3m-mobile-download-links .wallet=${this.wallet}></w3m-mobile-download-links>
    `}};au=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g}([(0,j.EM)("w3m-connecting-wc-unsupported")],au);var av=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aw=class extends ac{constructor(){if(super(),this.isLoading=!0,!this.wallet)throw Error("w3m-connecting-wc-web: No wallet provided");this.onConnect=this.onConnectProxy.bind(this),this.secondaryBtnLabel="Open",this.secondaryLabel=af.oU.CONNECT_LABELS.MOBILE,this.secondaryBtnIcon="externalLink",this.updateLoadingState(),this.unsubscribe.push(n.x.subscribeKey("wcUri",()=>{this.updateLoadingState()})),o.E.sendEvent({type:"track",event:"SELECT_WALLET",properties:{name:this.wallet.name,platform:"web",displayIndex:this.wallet?.display_index,walletRank:this.wallet?.order,view:p.I.state.view}})}updateLoadingState(){this.isLoading=!this.uri}onConnectProxy(){if(this.wallet?.webapp_link&&this.uri)try{this.error=!1;let{webapp_link:a,name:b}=this.wallet,{redirect:c,href:d}=f.w.formatUniversalUrl(a,this.uri);n.x.setWcLinking({name:b,href:d}),n.x.setRecentWallet(this.wallet),f.w.openHref(c,"_blank")}catch{this.error=!0}}};av([(0,e.wk)()],aw.prototype,"isLoading",void 0),aw=av([(0,j.EM)("w3m-connecting-wc-web")],aw);let ax=(0,j.AH)`
  :host([data-mobile-fullscreen='true']) {
    height: 100%;
    display: flex;
    flex-direction: column;
  }

  :host([data-mobile-fullscreen='true']) wui-ux-by-reown {
    margin-top: auto;
  }
`;var ay=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let az=class extends d.WF{constructor(){super(),this.wallet=p.I.state.data?.wallet,this.unsubscribe=[],this.platform=void 0,this.platforms=[],this.isSiwxEnabled=!!g.H.state.siwx,this.remoteFeatures=g.H.state.remoteFeatures,this.displayBranding=!0,this.basic=!1,this.determinePlatforms(),this.initializeConnection(),this.unsubscribe.push(g.H.subscribeKey("remoteFeatures",a=>this.remoteFeatures=a))}disconnectedCallback(){this.unsubscribe.forEach(a=>a())}render(){return g.H.state.enableMobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),(0,d.qy)`
      ${this.headerTemplate()}
      <div class="platform-container">${this.platformTemplate()}</div>
      ${this.reownBrandingTemplate()}
    `}reownBrandingTemplate(){return this.remoteFeatures?.reownBranding&&this.displayBranding?(0,d.qy)`<wui-ux-by-reown></wui-ux-by-reown>`:null}async initializeConnection(a=!1){if("browser"!==this.platform&&(!g.H.state.manualWCControl||a))try{let{wcPairingExpiry:b,status:c}=n.x.state,{redirectView:d}=p.I.state.data??{};if(a||g.H.state.enableEmbedded||f.w.isPairingExpired(b)||"connecting"===c){let a=n.x.getConnections(A.W.state.activeChain),b=this.remoteFeatures?.multiWallet,c=a.length>0;await n.x.connectWalletConnect({cache:"never"}),this.isSiwxEnabled||(c&&b?(p.I.replace("ProfileWallets"),B.P.showSuccess("New Wallet Added")):d?p.I.replace(d):C.W.close())}}catch(a){if(a instanceof Error&&a.message.includes("An error occurred when attempting to switch chain")&&!g.H.state.enableNetworkSwitch&&A.W.state.activeChain){A.W.setActiveCaipNetwork(E.R.getUnsupportedNetwork(`${A.W.state.activeChain}:${A.W.state.activeCaipNetwork?.id}`)),A.W.showUnsupportedChainUI();return}a instanceof D.A&&a.originalName===z.RQ.PROVIDER_RPC_ERROR_NAME.USER_REJECTED_REQUEST?o.E.sendEvent({type:"track",event:"USER_REJECTED",properties:{message:a.message}}):o.E.sendEvent({type:"track",event:"CONNECT_ERROR",properties:{message:a?.message??"Unknown"}}),n.x.setWcError(!0),B.P.showError(a.message??"Connection error"),n.x.resetWcConnection(),p.I.goBack()}}determinePlatforms(){if(!this.wallet){this.platforms.push("qrcode"),this.platform="qrcode";return}if(this.platform)return;let{mobile_link:a,desktop_link:b,webapp_link:c,injected:d,rdns:e}=this.wallet,h=d?.map(({injected_id:a})=>a).filter(Boolean),i=[...e?[e]:h??[]],j=!g.H.state.isUniversalProvider&&i.length,k=n.x.checkInstalled(i),l=j&&k,m=b&&!f.w.isMobile();l&&!A.W.state.noAdapters&&this.platforms.push("browser"),a&&this.platforms.push(f.w.isMobile()?"mobile":"qrcode"),c&&this.platforms.push("web"),m&&this.platforms.push("desktop"),l||!j||A.W.state.noAdapters||this.platforms.push("unsupported"),this.platform=this.platforms[0]}platformTemplate(){switch(this.platform){case"browser":return(0,d.qy)`<w3m-connecting-wc-browser></w3m-connecting-wc-browser>`;case"web":return(0,d.qy)`<w3m-connecting-wc-web></w3m-connecting-wc-web>`;case"desktop":return(0,d.qy)`
          <w3m-connecting-wc-desktop .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-desktop>
        `;case"mobile":return(0,d.qy)`
          <w3m-connecting-wc-mobile isMobile .onRetry=${()=>this.initializeConnection(!0)}>
          </w3m-connecting-wc-mobile>
        `;case"qrcode":return(0,d.qy)`<w3m-connecting-wc-qrcode ?basic=${this.basic}></w3m-connecting-wc-qrcode>`;default:return(0,d.qy)`<w3m-connecting-wc-unsupported></w3m-connecting-wc-unsupported>`}}headerTemplate(){return this.platforms.length>1?(0,d.qy)`
      <w3m-connecting-header
        .platforms=${this.platforms}
        .onSelectPlatfrom=${this.onSelectPlatform.bind(this)}
      >
      </w3m-connecting-header>
    `:null}async onSelectPlatform(a){let b=this.shadowRoot?.querySelector("div");b&&(await b.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.platform=a,b.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}};az.styles=ax,ay([(0,e.wk)()],az.prototype,"platform",void 0),ay([(0,e.wk)()],az.prototype,"platforms",void 0),ay([(0,e.wk)()],az.prototype,"isSiwxEnabled",void 0),ay([(0,e.wk)()],az.prototype,"remoteFeatures",void 0),ay([(0,e.MZ)({type:Boolean})],az.prototype,"displayBranding",void 0),ay([(0,e.MZ)({type:Boolean})],az.prototype,"basic",void 0),az=ay([(0,j.EM)("w3m-connecting-wc-view")],az);var aA=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aB=class extends d.WF{constructor(){super(),this.unsubscribe=[],this.isMobile=f.w.isMobile(),this.remoteFeatures=g.H.state.remoteFeatures,this.unsubscribe.push(g.H.subscribeKey("remoteFeatures",a=>this.remoteFeatures=a))}disconnectedCallback(){this.unsubscribe.forEach(a=>a())}render(){if(this.isMobile){let{featured:a,recommended:b}=h.N.state,{customWallets:c}=g.H.state,e=i.i.getRecentWallets(),f=a.length||b.length||c?.length||e.length;return(0,d.qy)`<wui-flex flexDirection="column" gap="2" .margin=${["1","3","3","3"]}>
        ${f?(0,d.qy)`<w3m-connector-list></w3m-connector-list>`:null}
        <w3m-all-wallets-widget></w3m-all-wallets-widget>
      </wui-flex>`}return(0,d.qy)`<wui-flex flexDirection="column" .padding=${["0","0","4","0"]}>
        <w3m-connecting-wc-view ?basic=${!0} .displayBranding=${!1}></w3m-connecting-wc-view>
        <wui-flex flexDirection="column" .padding=${["0","3","0","3"]}>
          <w3m-all-wallets-widget></w3m-all-wallets-widget>
        </wui-flex>
      </wui-flex>
      ${this.reownBrandingTemplate()} `}reownBrandingTemplate(){return this.remoteFeatures?.reownBranding?(0,d.qy)` <wui-flex flexDirection="column" .padding=${["1","0","1","0"]}>
      <wui-ux-by-reown></wui-ux-by-reown>
    </wui-flex>`:null}};aA([(0,e.wk)()],aB.prototype,"isMobile",void 0),aA([(0,e.wk)()],aB.prototype,"remoteFeatures",void 0),aB=aA([(0,j.EM)("w3m-connecting-wc-basic-view")],aB);var aC=c(65619);let{I:aD}=aC.ge;var aE=c(56705);let aF=(a,b)=>{let c=a._$AN;if(void 0===c)return!1;for(let a of c)a._$AO?.(b,!1),aF(a,b);return!0},aG=a=>{let b,c;do{if(void 0===(b=a._$AM))break;(c=b._$AN).delete(a),a=b}while(0===c?.size)},aH=a=>{for(let b;b=a._$AM;a=b){let c=b._$AN;if(void 0===c)b._$AN=c=new Set;else if(c.has(a))break;c.add(a),aK(b)}};function aI(a){void 0!==this._$AN?(aG(this),this._$AM=a,aH(this)):this._$AM=a}function aJ(a,b=!1,c=0){let d=this._$AH,e=this._$AN;if(void 0!==e&&0!==e.size)if(b)if(Array.isArray(d))for(let a=c;a<d.length;a++)aF(d[a],!1),aG(d[a]);else null!=d&&(aF(d,!1),aG(d));else aF(this,a)}let aK=a=>{a.type==aE.OA.CHILD&&(a._$AP??=aJ,a._$AQ??=aI)};class aL extends aE.WL{constructor(){super(...arguments),this._$AN=void 0}_$AT(a,b,c){super._$AT(a,b,c),aH(this),this.isConnected=a._$AU}_$AO(a,b=!0){a!==this.isConnected&&(this.isConnected=a,a?this.reconnected?.():this.disconnected?.()),b&&(aF(this,a),aG(this))}setValue(a){if(void 0===this._$Ct.strings)this._$Ct._$AI(a,this);else{let b=[...this._$Ct._$AH];b[this._$Ci]=a,this._$Ct._$AI(b,this,0)}}disconnected(){}reconnected(){}}let aM=()=>new aN;class aN{}let aO=new WeakMap,aP=(0,aE.u$)(class extends aL{render(a){return aC.s6}update(a,[b]){let c=b!==this.G;return c&&void 0!==this.G&&this.rt(void 0),(c||this.lt!==this.ct)&&(this.G=b,this.ht=a.options?.host,this.rt(this.ct=a.element)),aC.s6}rt(a){if(this.isConnected||(a=void 0),"function"==typeof this.G){let b=this.ht??globalThis,c=aO.get(b);void 0===c&&(c=new WeakMap,aO.set(b,c)),void 0!==c.get(this.G)&&this.G.call(this.ht,void 0),c.set(this.G,a),void 0!==a&&this.G.call(this.ht,a)}else this.G.value=a}get lt(){return"function"==typeof this.G?aO.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}}),aQ=(0,H.AH)`
  :host {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  label {
    position: relative;
    display: inline-block;
    user-select: none;
    transition:
      background-color ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      color ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      border ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      box-shadow ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      width ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      height ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      transform ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      opacity ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  input {
    width: 0;
    height: 0;
    opacity: 0;
  }

  span {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: ${({colors:a})=>a.neutrals300};
    border-radius: ${({borderRadius:a})=>a.round};
    border: 1px solid transparent;
    will-change: border;
    transition:
      background-color ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      color ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      border ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      box-shadow ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      width ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      height ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]},
      transform ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      opacity ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]};
    will-change: background-color, color, border, box-shadow, width, height, transform, opacity;
  }

  span:before {
    content: '';
    position: absolute;
    background-color: ${({colors:a})=>a.white};
    border-radius: 50%;
  }

  /* -- Sizes --------------------------------------------------------- */
  label[data-size='lg'] {
    width: 48px;
    height: 32px;
  }

  label[data-size='md'] {
    width: 40px;
    height: 28px;
  }

  label[data-size='sm'] {
    width: 32px;
    height: 22px;
  }

  label[data-size='lg'] > span:before {
    height: 24px;
    width: 24px;
    left: 4px;
    top: 3px;
  }

  label[data-size='md'] > span:before {
    height: 20px;
    width: 20px;
    left: 4px;
    top: 3px;
  }

  label[data-size='sm'] > span:before {
    height: 16px;
    width: 16px;
    left: 3px;
    top: 2px;
  }

  /* -- Focus states --------------------------------------------------- */
  input:focus-visible:not(:checked) + span,
  input:focus:not(:checked) + span {
    border: 1px solid ${({tokens:a})=>a.core.iconAccentPrimary};
    background-color: ${({tokens:a})=>a.theme.textTertiary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  input:focus-visible:checked + span,
  input:focus:checked + span {
    border: 1px solid ${({tokens:a})=>a.core.iconAccentPrimary};
    box-shadow: 0px 0px 0px 4px rgba(9, 136, 240, 0.2);
  }

  /* -- Checked states --------------------------------------------------- */
  input:checked + span {
    background-color: ${({tokens:a})=>a.core.iconAccentPrimary};
  }

  label[data-size='lg'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='md'] > input:checked + span:before {
    transform: translateX(calc(100% - 9px));
  }

  label[data-size='sm'] > input:checked + span:before {
    transform: translateX(calc(100% - 7px));
  }

  /* -- Hover states ------------------------------------------------------- */
  label:hover > input:not(:checked):not(:disabled) + span {
    background-color: ${({colors:a})=>a.neutrals400};
  }

  label:hover > input:checked:not(:disabled) + span {
    background-color: ${({colors:a})=>a.accent080};
  }

  /* -- Disabled state --------------------------------------------------- */
  label:has(input:disabled) {
    pointer-events: none;
    user-select: none;
  }

  input:not(:checked):disabled + span {
    background-color: ${({colors:a})=>a.neutrals700};
  }

  input:checked:disabled + span {
    background-color: ${({colors:a})=>a.neutrals700};
  }

  input:not(:checked):disabled + span::before {
    background-color: ${({colors:a})=>a.neutrals400};
  }

  input:checked:disabled + span::before {
    background-color: ${({tokens:a})=>a.theme.textTertiary};
  }
`;var aR=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aS=class extends d.WF{constructor(){super(...arguments),this.inputElementRef=aM(),this.checked=!1,this.disabled=!1,this.size="md"}render(){return(0,d.qy)`
      <label data-size=${this.size}>
        <input
          ${aP(this.inputElementRef)}
          type="checkbox"
          ?checked=${this.checked}
          ?disabled=${this.disabled}
          @change=${this.dispatchChangeEvent.bind(this)}
        />
        <span></span>
      </label>
    `}dispatchChangeEvent(){this.dispatchEvent(new CustomEvent("switchChange",{detail:this.inputElementRef.value?.checked,bubbles:!0,composed:!0}))}};aS.styles=[F.W5,F.fD,aQ],aR([(0,e.MZ)({type:Boolean})],aS.prototype,"checked",void 0),aR([(0,e.MZ)({type:Boolean})],aS.prototype,"disabled",void 0),aR([(0,e.MZ)()],aS.prototype,"size",void 0),aS=aR([(0,G.E)("wui-toggle")],aS);let aT=(0,H.AH)`
  :host {
    height: auto;
  }

  :host > wui-flex {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    column-gap: ${({spacing:a})=>a["2"]};
    padding: ${({spacing:a})=>a["2"]} ${({spacing:a})=>a["3"]};
    background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    border-radius: ${({borderRadius:a})=>a["4"]};
    box-shadow: inset 0 0 0 1px ${({tokens:a})=>a.theme.foregroundPrimary};
    transition: background-color ${({durations:a})=>a.lg}
      ${({easings:a})=>a["ease-out-power-2"]};
    will-change: background-color;
    cursor: pointer;
  }

  wui-switch {
    pointer-events: none;
  }
`;var aU=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aV=class extends d.WF{constructor(){super(...arguments),this.checked=!1}render(){return(0,d.qy)`
      <wui-flex>
        <wui-icon size="xl" name="walletConnectBrown"></wui-icon>
        <wui-toggle
          ?checked=${this.checked}
          size="sm"
          @switchChange=${this.handleToggleChange.bind(this)}
        ></wui-toggle>
      </wui-flex>
    `}handleToggleChange(a){a.stopPropagation(),this.checked=a.detail,this.dispatchSwitchEvent()}dispatchSwitchEvent(){this.dispatchEvent(new CustomEvent("certifiedSwitchChange",{detail:this.checked,bubbles:!0,composed:!0}))}};aV.styles=[F.W5,F.fD,aT],aU([(0,e.MZ)({type:Boolean})],aV.prototype,"checked",void 0),aV=aU([(0,G.E)("wui-certified-switch")],aV);let aW=(0,H.AH)`
  :host {
    position: relative;
    width: 100%;
    display: inline-flex;
    flex-direction: column;
    gap: ${({spacing:a})=>a[3]};
    color: ${({tokens:a})=>a.theme.textPrimary};
    caret-color: ${({tokens:a})=>a.core.textAccentPrimary};
  }

  .wui-input-text-container {
    position: relative;
    display: flex;
  }

  input {
    width: 100%;
    border-radius: ${({borderRadius:a})=>a[4]};
    color: inherit;
    background: transparent;
    border: 1px solid ${({tokens:a})=>a.theme.borderPrimary};
    caret-color: ${({tokens:a})=>a.core.textAccentPrimary};
    padding: ${({spacing:a})=>a[3]} ${({spacing:a})=>a[3]}
      ${({spacing:a})=>a[3]} ${({spacing:a})=>a[10]};
    font-size: ${({textSize:a})=>a.large};
    line-height: ${({typography:a})=>a["lg-regular"].lineHeight};
    letter-spacing: ${({typography:a})=>a["lg-regular"].letterSpacing};
    font-weight: ${({fontWeight:a})=>a.regular};
    font-family: ${({fontFamily:a})=>a.regular};
  }

  input[data-size='lg'] {
    padding: ${({spacing:a})=>a[4]} ${({spacing:a})=>a[3]}
      ${({spacing:a})=>a[4]} ${({spacing:a})=>a[10]};
  }

  @media (hover: hover) and (pointer: fine) {
    input:hover:enabled {
      border: 1px solid ${({tokens:a})=>a.theme.borderSecondary};
    }
  }

  input:disabled {
    cursor: unset;
    border: 1px solid ${({tokens:a})=>a.theme.borderPrimary};
  }

  input::placeholder {
    color: ${({tokens:a})=>a.theme.textSecondary};
  }

  input:focus:enabled {
    border: 1px solid ${({tokens:a})=>a.theme.borderSecondary};
    background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    -webkit-box-shadow: 0px 0px 0px 4px ${({tokens:a})=>a.core.foregroundAccent040};
    -moz-box-shadow: 0px 0px 0px 4px ${({tokens:a})=>a.core.foregroundAccent040};
    box-shadow: 0px 0px 0px 4px ${({tokens:a})=>a.core.foregroundAccent040};
  }

  div.wui-input-text-container:has(input:disabled) {
    opacity: 0.5;
  }

  wui-icon.wui-input-text-left-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    pointer-events: none;
    left: ${({spacing:a})=>a[4]};
    color: ${({tokens:a})=>a.theme.iconDefault};
  }

  button.wui-input-text-submit-button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:a})=>a[3]};
    width: 24px;
    height: 24px;
    border: none;
    background: transparent;
    border-radius: ${({borderRadius:a})=>a[2]};
    color: ${({tokens:a})=>a.core.textAccentPrimary};
  }

  button.wui-input-text-submit-button:disabled {
    opacity: 1;
  }

  button.wui-input-text-submit-button.loading wui-icon {
    animation: spin 1s linear infinite;
  }

  button.wui-input-text-submit-button:hover {
    background: ${({tokens:a})=>a.core.foregroundAccent010};
  }

  input:has(+ .wui-input-text-submit-button) {
    padding-right: ${({spacing:a})=>a[12]};
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  input[type='search']::-webkit-search-decoration,
  input[type='search']::-webkit-search-cancel-button,
  input[type='search']::-webkit-search-results-button,
  input[type='search']::-webkit-search-results-decoration {
    -webkit-appearance: none;
  }

  /* -- Keyframes --------------------------------------------------- */
  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }
`;var aX=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let aY=class extends d.WF{constructor(){super(...arguments),this.inputElementRef=aM(),this.disabled=!1,this.loading=!1,this.placeholder="",this.type="text",this.value="",this.size="md"}render(){return(0,d.qy)` <div class="wui-input-text-container">
        ${this.templateLeftIcon()}
        <input
          data-size=${this.size}
          ${aP(this.inputElementRef)}
          data-testid="wui-input-text"
          type=${this.type}
          enterkeyhint=${(0,k.J)(this.enterKeyHint)}
          ?disabled=${this.disabled}
          placeholder=${this.placeholder}
          @input=${this.dispatchInputChangeEvent.bind(this)}
          @keydown=${this.onKeyDown}
          .value=${this.value||""}
        />
        ${this.templateSubmitButton()}
        <slot class="wui-input-text-slot"></slot>
      </div>
      ${this.templateError()} ${this.templateWarning()}`}templateLeftIcon(){return this.icon?(0,d.qy)`<wui-icon
        class="wui-input-text-left-icon"
        size="md"
        data-size=${this.size}
        color="inherit"
        name=${this.icon}
      ></wui-icon>`:null}templateSubmitButton(){return this.onSubmit?(0,d.qy)`<button
        class="wui-input-text-submit-button ${this.loading?"loading":""}"
        @click=${this.onSubmit?.bind(this)}
        ?disabled=${this.disabled||this.loading}
      >
        ${this.loading?(0,d.qy)`<wui-icon name="spinner" size="md"></wui-icon>`:(0,d.qy)`<wui-icon name="chevronRight" size="md"></wui-icon>`}
      </button>`:null}templateError(){return this.errorText?(0,d.qy)`<wui-text variant="sm-regular" color="error">${this.errorText}</wui-text>`:null}templateWarning(){return this.warningText?(0,d.qy)`<wui-text variant="sm-regular" color="warning">${this.warningText}</wui-text>`:null}dispatchInputChangeEvent(){this.dispatchEvent(new CustomEvent("inputChange",{detail:this.inputElementRef.value?.value,bubbles:!0,composed:!0}))}};aY.styles=[F.W5,F.fD,aW],aX([(0,e.MZ)()],aY.prototype,"icon",void 0),aX([(0,e.MZ)({type:Boolean})],aY.prototype,"disabled",void 0),aX([(0,e.MZ)({type:Boolean})],aY.prototype,"loading",void 0),aX([(0,e.MZ)()],aY.prototype,"placeholder",void 0),aX([(0,e.MZ)()],aY.prototype,"type",void 0),aX([(0,e.MZ)()],aY.prototype,"value",void 0),aX([(0,e.MZ)()],aY.prototype,"errorText",void 0),aX([(0,e.MZ)()],aY.prototype,"warningText",void 0),aX([(0,e.MZ)()],aY.prototype,"onSubmit",void 0),aX([(0,e.MZ)()],aY.prototype,"size",void 0),aX([(0,e.MZ)({attribute:!1})],aY.prototype,"onKeyDown",void 0),aY=aX([(0,G.E)("wui-input-text")],aY);let aZ=(0,H.AH)`
  :host {
    position: relative;
    display: inline-block;
    width: 100%;
  }

  wui-icon {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: ${({spacing:a})=>a[3]};
    color: ${({tokens:a})=>a.theme.iconDefault};
    cursor: pointer;
    padding: ${({spacing:a})=>a[2]};
    background-color: transparent;
    border-radius: ${({borderRadius:a})=>a[4]};
    transition: background-color ${({durations:a})=>a.lg}
      ${({easings:a})=>a["ease-out-power-2"]};
  }

  @media (hover: hover) {
    wui-icon:hover {
      background-color: ${({tokens:a})=>a.theme.foregroundSecondary};
    }
  }
`;var a$=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let a_=class extends d.WF{constructor(){super(...arguments),this.inputComponentRef=aM(),this.inputValue=""}render(){return(0,d.qy)`
      <wui-input-text
        ${aP(this.inputComponentRef)}
        placeholder="Search wallet"
        icon="search"
        type="search"
        enterKeyHint="search"
        size="sm"
        @inputChange=${this.onInputChange}
      >
        ${this.inputValue?(0,d.qy)`<wui-icon
              @click=${this.clearValue}
              color="inherit"
              size="sm"
              name="close"
            ></wui-icon>`:null}
      </wui-input-text>
    `}onInputChange(a){this.inputValue=a.detail||""}clearValue(){let a=this.inputComponentRef.value,b=a?.inputElementRef.value;b&&(b.value="",this.inputValue="",b.focus(),b.dispatchEvent(new Event("input")))}};a_.styles=[F.W5,aZ],a$([(0,e.MZ)()],a_.prototype,"inputValue",void 0),a_=a$([(0,G.E)("wui-search-bar")],a_);let a0=(0,d.JW)`<svg  viewBox="0 0 48 54" fill="none">
  <path
    d="M43.4605 10.7248L28.0485 1.61089C25.5438 0.129705 22.4562 0.129705 19.9515 1.61088L4.53951 10.7248C2.03626 12.2051 0.5 14.9365 0.5 17.886V36.1139C0.5 39.0635 2.03626 41.7949 4.53951 43.2752L19.9515 52.3891C22.4562 53.8703 25.5438 53.8703 28.0485 52.3891L43.4605 43.2752C45.9637 41.7949 47.5 39.0635 47.5 36.114V17.8861C47.5 14.9365 45.9637 12.2051 43.4605 10.7248Z"
  />
</svg>`,a1=(0,H.AH)`
  :host {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 104px;
    width: 104px;
    row-gap: ${({spacing:a})=>a[2]};
    background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    border-radius: ${({borderRadius:a})=>a[5]};
    position: relative;
  }

  wui-shimmer[data-type='network'] {
    border: none;
    -webkit-clip-path: var(--apkt-path-network);
    clip-path: var(--apkt-path-network);
  }

  svg {
    position: absolute;
    width: 48px;
    height: 54px;
    z-index: 1;
  }

  svg > path {
    stroke: ${({tokens:a})=>a.theme.foregroundSecondary};
    stroke-width: 1px;
  }

  @media (max-width: 350px) {
    :host {
      width: 100%;
    }
  }
`;var a2=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let a3=class extends d.WF{constructor(){super(...arguments),this.type="wallet"}render(){return(0,d.qy)`
      ${this.shimmerTemplate()}
      <wui-shimmer width="80px" height="20px"></wui-shimmer>
    `}shimmerTemplate(){return"network"===this.type?(0,d.qy)` <wui-shimmer data-type=${this.type} width="48px" height="54px"></wui-shimmer>
        ${a0}`:(0,d.qy)`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}};a3.styles=[F.W5,F.fD,a1],a2([(0,e.MZ)()],a3.prototype,"type",void 0),a3=a2([(0,G.E)("wui-card-select-loader")],a3);var a4=c(46690);let a5=(0,d.AH)`
  :host {
    display: grid;
    width: inherit;
    height: inherit;
  }
`;var a6=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let a7=class extends d.WF{render(){return this.style.cssText=`
      grid-template-rows: ${this.gridTemplateRows};
      grid-template-columns: ${this.gridTemplateColumns};
      justify-items: ${this.justifyItems};
      align-items: ${this.alignItems};
      justify-content: ${this.justifyContent};
      align-content: ${this.alignContent};
      column-gap: ${this.columnGap&&`var(--apkt-spacing-${this.columnGap})`};
      row-gap: ${this.rowGap&&`var(--apkt-spacing-${this.rowGap})`};
      gap: ${this.gap&&`var(--apkt-spacing-${this.gap})`};
      padding-top: ${this.padding&&a4.Z.getSpacingStyles(this.padding,0)};
      padding-right: ${this.padding&&a4.Z.getSpacingStyles(this.padding,1)};
      padding-bottom: ${this.padding&&a4.Z.getSpacingStyles(this.padding,2)};
      padding-left: ${this.padding&&a4.Z.getSpacingStyles(this.padding,3)};
      margin-top: ${this.margin&&a4.Z.getSpacingStyles(this.margin,0)};
      margin-right: ${this.margin&&a4.Z.getSpacingStyles(this.margin,1)};
      margin-bottom: ${this.margin&&a4.Z.getSpacingStyles(this.margin,2)};
      margin-left: ${this.margin&&a4.Z.getSpacingStyles(this.margin,3)};
    `,(0,d.qy)`<slot></slot>`}};a7.styles=[F.W5,a5],a6([(0,e.MZ)()],a7.prototype,"gridTemplateRows",void 0),a6([(0,e.MZ)()],a7.prototype,"gridTemplateColumns",void 0),a6([(0,e.MZ)()],a7.prototype,"justifyItems",void 0),a6([(0,e.MZ)()],a7.prototype,"alignItems",void 0),a6([(0,e.MZ)()],a7.prototype,"justifyContent",void 0),a6([(0,e.MZ)()],a7.prototype,"alignContent",void 0),a6([(0,e.MZ)()],a7.prototype,"columnGap",void 0),a6([(0,e.MZ)()],a7.prototype,"rowGap",void 0),a6([(0,e.MZ)()],a7.prototype,"gap",void 0),a6([(0,e.MZ)()],a7.prototype,"padding",void 0),a6([(0,e.MZ)()],a7.prototype,"margin",void 0),a7=a6([(0,G.E)("wui-grid")],a7);var a8=c(28284);let a9=(0,j.AH)`
  button {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    width: 104px;
    row-gap: ${({spacing:a})=>a["2"]};
    padding: ${({spacing:a})=>a["3"]} ${({spacing:a})=>a["0"]};
    background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    border-radius: clamp(0px, ${({borderRadius:a})=>a["4"]}, 20px);
    transition:
      color ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-1"]},
      background-color ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-1"]},
      border-radius ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-1"]};
    will-change: background-color, color, border-radius;
    outline: none;
    border: none;
  }

  button > wui-flex > wui-text {
    color: ${({tokens:a})=>a.theme.textPrimary};
    max-width: 86px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    justify-content: center;
  }

  button > wui-flex > wui-text.certified {
    max-width: 66px;
  }

  @media (hover: hover) and (pointer: fine) {
    button:hover:enabled {
      background-color: ${({tokens:a})=>a.theme.foregroundSecondary};
    }
  }

  button:disabled > wui-flex > wui-text {
    color: ${({tokens:a})=>a.core.glass010};
  }

  [data-selected='true'] {
    background-color: ${({colors:a})=>a.accent020};
  }

  @media (hover: hover) and (pointer: fine) {
    [data-selected='true']:hover:enabled {
      background-color: ${({colors:a})=>a.accent010};
    }
  }

  [data-selected='true']:active:enabled {
    background-color: ${({colors:a})=>a.accent010};
  }

  @media (max-width: 350px) {
    button {
      width: 100%;
    }
  }
`;var ba=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let bb=class extends d.WF{constructor(){super(),this.observer=new IntersectionObserver(()=>void 0),this.visible=!1,this.imageSrc=void 0,this.imageLoading=!1,this.isImpressed=!1,this.explorerId="",this.walletQuery="",this.certified=!1,this.displayIndex=0,this.wallet=void 0,this.observer=new IntersectionObserver(a=>{a.forEach(a=>{a.isIntersecting?(this.visible=!0,this.fetchImageSrc(),this.sendImpressionEvent()):this.visible=!1})},{threshold:.01})}firstUpdated(){this.observer.observe(this)}disconnectedCallback(){this.observer.disconnect()}render(){let a=this.wallet?.badge_type==="certified";return(0,d.qy)`
      <button>
        ${this.imageTemplate()}
        <wui-flex flexDirection="row" alignItems="center" justifyContent="center" gap="1">
          <wui-text
            variant="md-regular"
            color="inherit"
            class=${(0,k.J)(a?"certified":void 0)}
            >${this.wallet?.name}</wui-text
          >
          ${a?(0,d.qy)`<wui-icon size="sm" name="walletConnectBrown"></wui-icon>`:null}
        </wui-flex>
      </button>
    `}imageTemplate(){return(this.visible||this.imageSrc)&&!this.imageLoading?(0,d.qy)`
      <wui-wallet-image
        size="lg"
        imageSrc=${(0,k.J)(this.imageSrc)}
        name=${(0,k.J)(this.wallet?.name)}
        .installed=${this.wallet?.installed??!1}
        badgeSize="sm"
      >
      </wui-wallet-image>
    `:this.shimmerTemplate()}shimmerTemplate(){return(0,d.qy)`<wui-shimmer width="56px" height="56px"></wui-shimmer>`}async fetchImageSrc(){!this.wallet||(this.imageSrc=t.$.getWalletImage(this.wallet),this.imageSrc||(this.imageLoading=!0,this.imageSrc=await t.$.fetchWalletImage(this.wallet.image_id),this.imageLoading=!1))}sendImpressionEvent(){this.wallet&&!this.isImpressed&&(this.isImpressed=!0,o.E.sendWalletImpressionEvent({name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.explorerId,view:p.I.state.view,query:this.walletQuery,certified:this.certified,displayIndex:this.displayIndex}))}};bb.styles=a9,ba([(0,e.wk)()],bb.prototype,"visible",void 0),ba([(0,e.wk)()],bb.prototype,"imageSrc",void 0),ba([(0,e.wk)()],bb.prototype,"imageLoading",void 0),ba([(0,e.wk)()],bb.prototype,"isImpressed",void 0),ba([(0,e.MZ)()],bb.prototype,"explorerId",void 0),ba([(0,e.MZ)()],bb.prototype,"walletQuery",void 0),ba([(0,e.MZ)()],bb.prototype,"certified",void 0),ba([(0,e.MZ)()],bb.prototype,"displayIndex",void 0),ba([(0,e.MZ)({type:Object})],bb.prototype,"wallet",void 0),bb=ba([(0,j.EM)("w3m-all-wallets-list-item")],bb);let bc=(0,j.AH)`
  wui-grid {
    max-height: clamp(360px, 400px, 80vh);
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  w3m-all-wallets-list-item {
    opacity: 0;
    animation-duration: ${({durations:a})=>a.xl};
    animation-timing-function: ${({easings:a})=>a["ease-inout-power-2"]};
    animation-name: fade-in;
    animation-fill-mode: forwards;
  }

  @keyframes fade-in {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  wui-loading-spinner {
    padding-top: ${({spacing:a})=>a["4"]};
    padding-bottom: ${({spacing:a})=>a["4"]};
    justify-content: center;
    grid-column: 1 / span 4;
  }
`;var bd=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let be="local-paginator",bf=class extends d.WF{constructor(){super(),this.unsubscribe=[],this.paginationObserver=void 0,this.loading=!h.N.state.wallets.length,this.wallets=h.N.state.wallets,this.recommended=h.N.state.recommended,this.featured=h.N.state.featured,this.filteredWallets=h.N.state.filteredWallets,this.mobileFullScreen=g.H.state.enableMobileFullScreen,this.unsubscribe.push(h.N.subscribeKey("wallets",a=>this.wallets=a),h.N.subscribeKey("recommended",a=>this.recommended=a),h.N.subscribeKey("featured",a=>this.featured=a),h.N.subscribeKey("filteredWallets",a=>this.filteredWallets=a))}firstUpdated(){this.initialFetch(),this.createPaginationObserver()}disconnectedCallback(){this.unsubscribe.forEach(a=>a()),this.paginationObserver?.disconnect()}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),(0,d.qy)`
      <wui-grid
        data-scroll=${!this.loading}
        .padding=${["0","3","3","3"]}
        gap="2"
        justifyContent="space-between"
      >
        ${this.loading?this.shimmerTemplate(16):this.walletsTemplate()}
        ${this.paginationLoaderTemplate()}
      </wui-grid>
    `}async initialFetch(){this.loading=!0;let a=this.shadowRoot?.querySelector("wui-grid");a&&(await h.N.fetchWalletsByPage({page:1}),await a.animate([{opacity:1},{opacity:0}],{duration:200,fill:"forwards",easing:"ease"}).finished,this.loading=!1,a.animate([{opacity:0},{opacity:1}],{duration:200,fill:"forwards",easing:"ease"}))}shimmerTemplate(a,b){return[...Array(a)].map(()=>(0,d.qy)`
        <wui-card-select-loader type="wallet" id=${(0,k.J)(b)}></wui-card-select-loader>
      `)}getWallets(){let a=[...this.featured,...this.recommended];this.filteredWallets?.length>0?a.push(...this.filteredWallets):a.push(...this.wallets);let b=f.w.uniqueBy(a,"id"),c=a8.A.markWalletsAsInstalled(b);return a8.A.markWalletsWithDisplayIndex(c)}walletsTemplate(){return this.getWallets().map((a,b)=>(0,d.qy)`
        <w3m-all-wallets-list-item
          data-testid="wallet-search-item-${a.id}"
          @click=${()=>this.onConnectWallet(a)}
          .wallet=${a}
          explorerId=${a.id}
          certified=${"certified"===this.badge}
          displayIndex=${b}
        ></w3m-all-wallets-list-item>
      `)}paginationLoaderTemplate(){let{wallets:a,recommended:b,featured:c,count:d,mobileFilteredOutWalletsLength:e}=h.N.state,f=window.innerWidth<352?3:4,g=a.length+b.length,i=Math.ceil(g/f)*f-g+f;return(i-=a.length?c.length%f:0,0===d&&c.length>0)?null:0===d||[...c,...a,...b].length<d-(e??0)?this.shimmerTemplate(i,be):null}createPaginationObserver(){let a=this.shadowRoot?.querySelector(`#${be}`);a&&(this.paginationObserver=new IntersectionObserver(([a])=>{if(a?.isIntersecting&&!this.loading){let{page:a,count:b,wallets:c}=h.N.state;c.length<b&&h.N.fetchWalletsByPage({page:a+1})}}),this.paginationObserver.observe(a))}onConnectWallet(a){m.a.selectWalletConnector(a)}};bf.styles=bc,bd([(0,e.wk)()],bf.prototype,"loading",void 0),bd([(0,e.wk)()],bf.prototype,"wallets",void 0),bd([(0,e.wk)()],bf.prototype,"recommended",void 0),bd([(0,e.wk)()],bf.prototype,"featured",void 0),bd([(0,e.wk)()],bf.prototype,"filteredWallets",void 0),bd([(0,e.wk)()],bf.prototype,"badge",void 0),bd([(0,e.wk)()],bf.prototype,"mobileFullScreen",void 0),bf=bd([(0,j.EM)("w3m-all-wallets-list")],bf),c(74085);let bg=(0,d.AH)`
  wui-grid,
  wui-loading-spinner,
  wui-flex {
    height: 360px;
  }

  wui-grid {
    overflow: scroll;
    scrollbar-width: none;
    grid-auto-rows: min-content;
    grid-template-columns: repeat(auto-fill, 104px);
  }

  :host([data-mobile-fullscreen='true']) wui-grid {
    max-height: none;
    height: auto;
  }

  wui-grid[data-scroll='false'] {
    overflow: hidden;
  }

  wui-grid::-webkit-scrollbar {
    display: none;
  }

  wui-loading-spinner {
    justify-content: center;
    align-items: center;
  }

  @media (max-width: 350px) {
    wui-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }
`;var bh=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let bi=class extends d.WF{constructor(){super(...arguments),this.prevQuery="",this.prevBadge=void 0,this.loading=!0,this.mobileFullScreen=g.H.state.enableMobileFullScreen,this.query=""}render(){return this.mobileFullScreen&&this.setAttribute("data-mobile-fullscreen","true"),this.onSearch(),this.loading?(0,d.qy)`<wui-loading-spinner color="accent-primary"></wui-loading-spinner>`:this.walletsTemplate()}async onSearch(){(this.query.trim()!==this.prevQuery.trim()||this.badge!==this.prevBadge)&&(this.prevQuery=this.query,this.prevBadge=this.badge,this.loading=!0,await h.N.searchWallet({search:this.query,badge:this.badge}),this.loading=!1)}walletsTemplate(){let{search:a}=h.N.state,b=a8.A.markWalletsAsInstalled(a);return a.length?(0,d.qy)`
      <wui-grid
        data-testid="wallet-list"
        .padding=${["0","3","3","3"]}
        rowGap="4"
        columngap="2"
        justifyContent="space-between"
      >
        ${b.map((a,b)=>(0,d.qy)`
            <w3m-all-wallets-list-item
              @click=${()=>this.onConnectWallet(a)}
              .wallet=${a}
              data-testid="wallet-search-item-${a.id}"
              explorerId=${a.id}
              certified=${"certified"===this.badge}
              walletQuery=${this.query}
              displayIndex=${b}
            ></w3m-all-wallets-list-item>
          `)}
      </wui-grid>
    `:(0,d.qy)`
        <wui-flex
          data-testid="no-wallet-found"
          justifyContent="center"
          alignItems="center"
          gap="3"
          flexDirection="column"
        >
          <wui-icon-box size="lg" color="default" icon="wallet"></wui-icon-box>
          <wui-text data-testid="no-wallet-found-text" color="secondary" variant="md-medium">
            No Wallet found
          </wui-text>
        </wui-flex>
      `}onConnectWallet(a){m.a.selectWalletConnector(a)}};bi.styles=bg,bh([(0,e.wk)()],bi.prototype,"loading",void 0),bh([(0,e.wk)()],bi.prototype,"mobileFullScreen",void 0),bh([(0,e.MZ)()],bi.prototype,"query",void 0),bh([(0,e.MZ)()],bi.prototype,"badge",void 0),bi=bh([(0,j.EM)("w3m-all-wallets-search")],bi);var bj=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let bk=class extends d.WF{constructor(){super(...arguments),this.search="",this.badge=void 0,this.onDebouncedSearch=f.w.debounce(a=>{this.search=a})}render(){let a=this.search.length>=2;return(0,d.qy)`
      <wui-flex .padding=${["1","3","3","3"]} gap="2" alignItems="center">
        <wui-search-bar @inputChange=${this.onInputChange.bind(this)}></wui-search-bar>
        <wui-certified-switch
          ?checked=${"certified"===this.badge}
          @certifiedSwitchChange=${this.onCertifiedSwitchChange.bind(this)}
          data-testid="wui-certified-switch"
        ></wui-certified-switch>
        ${this.qrButtonTemplate()}
      </wui-flex>
      ${a||this.badge?(0,d.qy)`<w3m-all-wallets-search
            query=${this.search}
            .badge=${this.badge}
          ></w3m-all-wallets-search>`:(0,d.qy)`<w3m-all-wallets-list .badge=${this.badge}></w3m-all-wallets-list>`}
    `}onInputChange(a){this.onDebouncedSearch(a.detail)}onCertifiedSwitchChange(a){a.detail?(this.badge="certified",B.P.showSvg("Only WalletConnect certified",{icon:"walletConnectBrown",iconColor:"accent-100"})):this.badge=void 0}qrButtonTemplate(){return f.w.isMobile()?(0,d.qy)`
        <wui-icon-box
          size="xl"
          iconSize="xl"
          color="accent-primary"
          icon="qrCode"
          border
          borderColor="wui-accent-glass-010"
          @click=${this.onWalletConnectQr.bind(this)}
        ></wui-icon-box>
      `:null}onWalletConnectQr(){p.I.push("ConnectingWalletConnect")}};bj([(0,e.wk)()],bk.prototype,"search",void 0),bj([(0,e.wk)()],bk.prototype,"badge",void 0),bk=bj([(0,j.EM)("w3m-all-wallets-view")],bk);let bl=(0,H.AH)`
  :host {
    width: 100%;
  }

  button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: ${({spacing:a})=>a[3]};
    width: 100%;
    background-color: ${({tokens:a})=>a.theme.backgroundPrimary};
    border-radius: ${({borderRadius:a})=>a[4]};
    transition:
      background-color ${({durations:a})=>a.lg}
        ${({easings:a})=>a["ease-out-power-2"]},
      scale ${({durations:a})=>a.lg} ${({easings:a})=>a["ease-out-power-2"]};
    will-change: background-color, scale;
  }

  wui-text {
    text-transform: capitalize;
  }

  wui-image {
    color: ${({tokens:a})=>a.theme.textPrimary};
  }

  @media (hover: hover) {
    button:hover:enabled {
      background-color: ${({tokens:a})=>a.theme.foregroundPrimary};
    }
  }

  button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;var bm=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g};let bn=class extends d.WF{constructor(){super(...arguments),this.imageSrc="google",this.loading=!1,this.disabled=!1,this.rightIcon=!0,this.rounded=!1,this.fullSize=!1}render(){return this.dataset.rounded=this.rounded?"true":"false",(0,d.qy)`
      <button
        ?disabled=${!!this.loading||!!this.disabled}
        data-loading=${this.loading}
        tabindex=${(0,k.J)(this.tabIdx)}
      >
        <wui-flex gap="2" alignItems="center">
          ${this.templateLeftIcon()}
          <wui-flex gap="1">
            <slot></slot>
          </wui-flex>
        </wui-flex>
        ${this.templateRightIcon()}
      </button>
    `}templateLeftIcon(){return this.icon?(0,d.qy)`<wui-image
        icon=${this.icon}
        iconColor=${(0,k.J)(this.iconColor)}
        ?boxed=${!0}
        ?rounded=${this.rounded}
      ></wui-image>`:(0,d.qy)`<wui-image
      ?boxed=${!0}
      ?rounded=${this.rounded}
      ?fullSize=${this.fullSize}
      src=${this.imageSrc}
    ></wui-image>`}templateRightIcon(){return this.rightIcon?this.loading?(0,d.qy)`<wui-loading-spinner size="md" color="accent-primary"></wui-loading-spinner>`:(0,d.qy)`<wui-icon name="chevronRight" size="lg" color="default"></wui-icon>`:null}};bn.styles=[F.W5,F.fD,bl],bm([(0,e.MZ)()],bn.prototype,"imageSrc",void 0),bm([(0,e.MZ)()],bn.prototype,"icon",void 0),bm([(0,e.MZ)()],bn.prototype,"iconColor",void 0),bm([(0,e.MZ)({type:Boolean})],bn.prototype,"loading",void 0),bm([(0,e.MZ)()],bn.prototype,"tabIdx",void 0),bm([(0,e.MZ)({type:Boolean})],bn.prototype,"disabled",void 0),bm([(0,e.MZ)({type:Boolean})],bn.prototype,"rightIcon",void 0),bm([(0,e.MZ)({type:Boolean})],bn.prototype,"rounded",void 0),bm([(0,e.MZ)({type:Boolean})],bn.prototype,"fullSize",void 0),bn=bm([(0,G.E)("wui-list-item")],bn);let bo=class extends d.WF{constructor(){super(...arguments),this.wallet=p.I.state.data?.wallet}render(){if(!this.wallet)throw Error("w3m-downloads-view");return(0,d.qy)`
      <wui-flex gap="2" flexDirection="column" .padding=${["3","3","4","3"]}>
        ${this.chromeTemplate()} ${this.iosTemplate()} ${this.androidTemplate()}
        ${this.homepageTemplate()}
      </wui-flex>
    `}chromeTemplate(){return this.wallet?.chrome_store?(0,d.qy)`<wui-list-item
      variant="icon"
      icon="chromeStore"
      iconVariant="square"
      @click=${this.onChromeStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Chrome Extension</wui-text>
    </wui-list-item>`:null}iosTemplate(){return this.wallet?.app_store?(0,d.qy)`<wui-list-item
      variant="icon"
      icon="appStore"
      iconVariant="square"
      @click=${this.onAppStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">iOS App</wui-text>
    </wui-list-item>`:null}androidTemplate(){return this.wallet?.play_store?(0,d.qy)`<wui-list-item
      variant="icon"
      icon="playStore"
      iconVariant="square"
      @click=${this.onPlayStore.bind(this)}
      chevron
    >
      <wui-text variant="md-medium" color="primary">Android App</wui-text>
    </wui-list-item>`:null}homepageTemplate(){return this.wallet?.homepage?(0,d.qy)`
      <wui-list-item
        variant="icon"
        icon="browser"
        iconVariant="square-blue"
        @click=${this.onHomePage.bind(this)}
        chevron
      >
        <wui-text variant="md-medium" color="primary">Website</wui-text>
      </wui-list-item>
    `:null}openStore(a){a.href&&this.wallet&&(o.E.sendEvent({type:"track",event:"GET_WALLET",properties:{name:this.wallet.name,walletRank:this.wallet.order,explorerId:this.wallet.id,type:a.type}}),f.w.openHref(a.href,"_blank"))}onChromeStore(){this.wallet?.chrome_store&&this.openStore({href:this.wallet.chrome_store,type:"chrome_store"})}onAppStore(){this.wallet?.app_store&&this.openStore({href:this.wallet.app_store,type:"app_store"})}onPlayStore(){this.wallet?.play_store&&this.openStore({href:this.wallet.play_store,type:"play_store"})}onHomePage(){this.wallet?.homepage&&this.openStore({href:this.wallet.homepage,type:"homepage"})}};bo=function(a,b,c,d){var e,f=arguments.length,g=f<3?b:null===d?d=Object.getOwnPropertyDescriptor(b,c):d;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)g=Reflect.decorate(a,b,c,d);else for(var h=a.length-1;h>=0;h--)(e=a[h])&&(g=(f<3?e(g):f>3?e(b,c,g):e(b,c))||g);return f>3&&g&&Object.defineProperty(b,c,g),g}([(0,j.EM)("w3m-downloads-view")],bo)},23372:(a,b,c)=>{"use strict";let d=c(28354),e=c(74075),f=c(57949),g=c(49840),h=c(96277),i=c(92858),j=c(83670),k=a.exports=function(a){f.call(this),this._parser=new h(a,{read:this.read.bind(this),error:this._handleError.bind(this),metadata:this._handleMetaData.bind(this),gamma:this.emit.bind(this,"gamma"),palette:this._handlePalette.bind(this),transColor:this._handleTransColor.bind(this),finished:this._finished.bind(this),inflateData:this._inflateData.bind(this),simpleTransparency:this._simpleTransparency.bind(this),headersFinished:this._headersFinished.bind(this)}),this._options=a,this.writable=!0,this._parser.start()};d.inherits(k,f),k.prototype._handleError=function(a){this.emit("error",a),this.writable=!1,this.destroy(),this._inflate&&this._inflate.destroy&&this._inflate.destroy(),this._filter&&(this._filter.destroy(),this._filter.on("error",function(){})),this.errord=!0},k.prototype._inflateData=function(a){if(!this._inflate)if(this._bitmapInfo.interlace)this._inflate=e.createInflate(),this._inflate.on("error",this.emit.bind(this,"error")),this._filter.on("complete",this._complete.bind(this)),this._inflate.pipe(this._filter);else{let a=((this._bitmapInfo.width*this._bitmapInfo.bpp*this._bitmapInfo.depth+7>>3)+1)*this._bitmapInfo.height,b=Math.max(a,e.Z_MIN_CHUNK);this._inflate=e.createInflate({chunkSize:b});let c=a,d=this.emit.bind(this,"error");this._inflate.on("error",function(a){c&&d(a)}),this._filter.on("complete",this._complete.bind(this));let f=this._filter.write.bind(this._filter);this._inflate.on("data",function(a){c&&(a.length>c&&(a=a.slice(0,c)),c-=a.length,f(a))}),this._inflate.on("end",this._filter.end.bind(this._filter))}this._inflate.write(a)},k.prototype._handleMetaData=function(a){this._metaData=a,this._bitmapInfo=Object.create(a),this._filter=new g(this._bitmapInfo)},k.prototype._handleTransColor=function(a){this._bitmapInfo.transColor=a},k.prototype._handlePalette=function(a){this._bitmapInfo.palette=a},k.prototype._simpleTransparency=function(){this._metaData.alpha=!0},k.prototype._headersFinished=function(){this.emit("metadata",this._metaData)},k.prototype._finished=function(){this.errord||(this._inflate?this._inflate.end():this.emit("error","No Inflate block"))},k.prototype._complete=function(a){let b;if(!this.errord){try{let c=i.dataToBitMap(a,this._bitmapInfo);b=j(c,this._bitmapInfo),c=null}catch(a){this._handleError(a);return}this.emit("parsed",b)}}},23548:(a,b,c)=>{let d=c(65966),e=c(93326),f=c(53300),g=c(9353);function h(a,b,c,f,g){let h=[].slice.call(arguments,1),i=h.length,j="function"==typeof h[i-1];if(!j&&!d())throw Error("Callback required as last argument");if(j){if(i<2)throw Error("Too few arguments provided");2===i?(g=c,c=b,b=f=void 0):3===i&&(b.getContext&&void 0===g?(g=f,f=void 0):(g=f,f=c,c=b,b=void 0))}else{if(i<1)throw Error("Too few arguments provided");return 1===i?(c=b,b=f=void 0):2!==i||b.getContext||(f=c,c=b,b=void 0),new Promise(function(d,g){try{let g=e.create(c,f);d(a(g,b,f))}catch(a){g(a)}})}try{let d=e.create(c,f);g(null,a(d,b,f))}catch(a){g(a)}}e.create,b.toCanvas=h.bind(null,f.render),h.bind(null,f.renderToDataURL),h.bind(null,function(a,b,c){return g.render(a,c)})},24566:(a,b)=>{b.L={bit:1},b.M={bit:0},b.Q={bit:3},b.H={bit:2},b.isValid=function(a){return a&&void 0!==a.bit&&a.bit>=0&&a.bit<4},b.from=function(a,c){if(b.isValid(a))return a;try{if("string"!=typeof a)throw Error("Param is not a string");switch(a.toLowerCase()){case"l":case"low":return b.L;case"m":case"medium":return b.M;case"q":case"quartile":return b.Q;case"h":case"high":return b.H;default:throw Error("Unknown EC Level: "+a)}}catch(a){return c}}},25010:(a,b,c)=>{let d=c(3615),e=c(16419),f=c(24566),g=c(51631),h=c(85171),i=d.getBCHDigit(7973);function j(a,b){return g.getCharCountIndicator(a,b)+4}b.from=function(a,b){return h.isValid(a)?parseInt(a,10):b},b.getCapacity=function(a,b,c){if(!h.isValid(a))throw Error("Invalid QR Code version");void 0===c&&(c=g.BYTE);let f=(d.getSymbolTotalCodewords(a)-e.getTotalCodewordsCount(a,b))*8;if(c===g.MIXED)return f;let i=f-j(c,a);switch(c){case g.NUMERIC:return Math.floor(i/10*3);case g.ALPHANUMERIC:return Math.floor(i/11*2);case g.KANJI:return Math.floor(i/13);case g.BYTE:default:return Math.floor(i/8)}},b.getBestVersionForData=function(a,c){let d,e=f.from(c,f.M);if(Array.isArray(a)){if(a.length>1){for(let c=1;c<=40;c++)if(function(a,b){let c=0;return a.forEach(function(a){let d=j(a.mode,b);c+=d+a.getBitsLength()}),c}(a,c)<=b.getCapacity(c,e,g.MIXED))return c;return}if(0===a.length)return 1;d=a[0]}else d=a;return function(a,c,d){for(let e=1;e<=40;e++)if(c<=b.getCapacity(e,d,a))return e}(d.mode,d.getLength(),e)},b.getEncodedBits=function(a){if(!h.isValid(a)||a<7)throw Error("Invalid QR Code version");let b=a<<12;for(;d.getBCHDigit(b)-i>=0;)b^=7973<<d.getBCHDigit(b)-i;return a<<12|b}},26716:(a,b,c)=>{let d=c(51631),e=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function f(a){this.mode=d.ALPHANUMERIC,this.data=a}f.getBitsLength=function(a){return 11*Math.floor(a/2)+a%2*6},f.prototype.getLength=function(){return this.data.length},f.prototype.getBitsLength=function(){return f.getBitsLength(this.data.length)},f.prototype.write=function(a){let b;for(b=0;b+2<=this.data.length;b+=2){let c=45*e.indexOf(this.data[b]);c+=e.indexOf(this.data[b+1]),a.put(c,11)}this.data.length%2&&a.put(e.indexOf(this.data[b]),6)},a.exports=f},26794:(a,b,c)=>{let d=c(51888);b.mul=function(a,b){let c=new Uint8Array(a.length+b.length-1);for(let e=0;e<a.length;e++)for(let f=0;f<b.length;f++)c[e+f]^=d.mul(a[e],b[f]);return c},b.mod=function(a,b){let c=new Uint8Array(a);for(;c.length-b.length>=0;){let a=c[0];for(let e=0;e<b.length;e++)c[e]^=d.mul(b[e],a);let e=0;for(;e<c.length&&0===c[e];)e++;c=c.slice(e)}return c},b.generateECPolynomial=function(a){let c=new Uint8Array([1]);for(let e=0;e<a;e++)c=b.mul(c,new Uint8Array([1,d.exp(e)]));return c}},27734:(a,b,c)=>{"use strict";let d=c(59725),e=c(55211);function f(a,b,c){let d=a*b;return 8!==c&&(d=Math.ceil(d/(8/c))),d}let g=a.exports=function(a,b){let c=a.width,e=a.height,g=a.interlace,h=a.bpp,i=a.depth;if(this.read=b.read,this.write=b.write,this.complete=b.complete,this._imageIndex=0,this._images=[],g){let a=d.getImagePasses(c,e);for(let b=0;b<a.length;b++)this._images.push({byteWidth:f(a[b].width,h,i),height:a[b].height,lineIndex:0})}else this._images.push({byteWidth:f(c,h,i),height:e,lineIndex:0});8===i?this._xComparison=h:16===i?this._xComparison=2*h:this._xComparison=1};g.prototype.start=function(){this.read(this._images[this._imageIndex].byteWidth+1,this._reverseFilterLine.bind(this))},g.prototype._unFilterType1=function(a,b,c){let d=this._xComparison,e=d-1;for(let f=0;f<c;f++){let c=a[1+f],g=f>e?b[f-d]:0;b[f]=c+g}},g.prototype._unFilterType2=function(a,b,c){let d=this._lastLine;for(let e=0;e<c;e++){let c=a[1+e],f=d?d[e]:0;b[e]=c+f}},g.prototype._unFilterType3=function(a,b,c){let d=this._xComparison,e=d-1,f=this._lastLine;for(let g=0;g<c;g++){let c=a[1+g],h=f?f[g]:0,i=Math.floor(((g>e?b[g-d]:0)+h)/2);b[g]=c+i}},g.prototype._unFilterType4=function(a,b,c){let d=this._xComparison,f=d-1,g=this._lastLine;for(let h=0;h<c;h++){let c=a[1+h],i=g?g[h]:0,j=e(h>f?b[h-d]:0,i,h>f&&g?g[h-d]:0);b[h]=c+j}},g.prototype._reverseFilterLine=function(a){let b,c=a[0],d=this._images[this._imageIndex],e=d.byteWidth;if(0===c)b=a.slice(1,e+1);else switch(b=Buffer.alloc(e),c){case 1:this._unFilterType1(a,b,e);break;case 2:this._unFilterType2(a,b,e);break;case 3:this._unFilterType3(a,b,e);break;case 4:this._unFilterType4(a,b,e);break;default:throw Error("Unrecognised filter type - "+c)}this.write(b),d.lineIndex++,d.lineIndex>=d.height?(this._lastLine=null,this._imageIndex++,d=this._images[this._imageIndex]):this._lastLine=b,d?this.read(d.byteWidth+1,this._reverseFilterLine.bind(this)):(this._lastLine=null,this.complete())}},30104:(a,b,c)=>{"use strict";a.exports=c(6885)},31964:(a,b,c)=>{"use strict";let d=c(55211),e={0:function(a,b,c,d,e){for(let f=0;f<c;f++)d[e+f]=a[b+f]},1:function(a,b,c,d,e,f){for(let g=0;g<c;g++){let c=g>=f?a[b+g-f]:0,h=a[b+g]-c;d[e+g]=h}},2:function(a,b,c,d,e){for(let f=0;f<c;f++){let g=b>0?a[b+f-c]:0,h=a[b+f]-g;d[e+f]=h}},3:function(a,b,c,d,e,f){for(let g=0;g<c;g++){let h=g>=f?a[b+g-f]:0,i=b>0?a[b+g-c]:0,j=a[b+g]-(h+i>>1);d[e+g]=j}},4:function(a,b,c,e,f,g){for(let h=0;h<c;h++){let i=h>=g?a[b+h-g]:0,j=b>0?a[b+h-c]:0,k=b>0&&h>=g?a[b+h-(c+g)]:0,l=a[b+h]-d(i,j,k);e[f+h]=l}}},f={0:function(a,b,c){let d=0,e=b+c;for(let c=b;c<e;c++)d+=Math.abs(a[c]);return d},1:function(a,b,c,d){let e=0;for(let f=0;f<c;f++){let c=f>=d?a[b+f-d]:0;e+=Math.abs(a[b+f]-c)}return e},2:function(a,b,c){let d=0,e=b+c;for(let f=b;f<e;f++){let e=b>0?a[f-c]:0;d+=Math.abs(a[f]-e)}return d},3:function(a,b,c,d){let e=0;for(let f=0;f<c;f++){let g=f>=d?a[b+f-d]:0,h=b>0?a[b+f-c]:0;e+=Math.abs(a[b+f]-(g+h>>1))}return e},4:function(a,b,c,e){let f=0;for(let g=0;g<c;g++){let h=g>=e?a[b+g-e]:0,i=b>0?a[b+g-c]:0,j=b>0&&g>=e?a[b+g-(c+e)]:0;f+=Math.abs(a[b+g]-d(h,i,j))}return f}};a.exports=function(a,b,c,d,g){let h;if("filterType"in d&&-1!==d.filterType)if("number"==typeof d.filterType)h=[d.filterType];else throw Error("unrecognised filter types");else h=[0,1,2,3,4];16===d.bitDepth&&(g*=2);let i=b*g,j=0,k=0,l=Buffer.alloc((i+1)*c),m=h[0];for(let b=0;b<c;b++){if(h.length>1){let b=1/0;for(let c=0;c<h.length;c++){let d=f[h[c]](a,k,i,g);d<b&&(m=h[c],b=d)}}l[j]=m,j++,e[m](a,k,i,l,j,g),j+=i,k+=i}return l}},32767:(a,b,c)=>{let d=c(33570),e=c(51631);function f(a){this.mode=e.BYTE,"string"==typeof a&&(a=d(a)),this.data=new Uint8Array(a)}f.getBitsLength=function(a){return 8*a},f.prototype.getLength=function(){return this.data.length},f.prototype.getBitsLength=function(){return f.getBitsLength(this.data.length)},f.prototype.write=function(a){for(let b=0,c=this.data.length;b<c;b++)a.put(this.data[b],8)},a.exports=f},33570:a=>{"use strict";a.exports=function(a){for(var b=[],c=a.length,d=0;d<c;d++){var e=a.charCodeAt(d);if(e>=55296&&e<=56319&&c>d+1){var f=a.charCodeAt(d+1);f>=56320&&f<=57343&&(e=(e-55296)*1024+f-56320+65536,d+=1)}if(e<128){b.push(e);continue}if(e<2048){b.push(e>>6|192),b.push(63&e|128);continue}if(e<55296||e>=57344&&e<65536){b.push(e>>12|224),b.push(e>>6&63|128),b.push(63&e|128);continue}if(e>=65536&&e<=1114111){b.push(e>>18|240),b.push(e>>12&63|128),b.push(e>>6&63|128),b.push(63&e|128);continue}b.push(239,191,189)}return new Uint8Array(b).buffer}},34447:(a,b,c)=>{"use strict";let d=c(28354),e=c(27910),f=c(23372),g=c(49149),h=c(58879),i=b.O=function(a){e.call(this),a=a||{},this.width=0|a.width,this.height=0|a.height,this.data=this.width>0&&this.height>0?Buffer.alloc(4*this.width*this.height):null,a.fill&&this.data&&this.data.fill(0),this.gamma=0,this.readable=this.writable=!0,this._parser=new f(a),this._parser.on("error",this.emit.bind(this,"error")),this._parser.on("close",this._handleClose.bind(this)),this._parser.on("metadata",this._metadata.bind(this)),this._parser.on("gamma",this._gamma.bind(this)),this._parser.on("parsed",(function(a){this.data=a,this.emit("parsed",a)}).bind(this)),this._packer=new g(a),this._packer.on("data",this.emit.bind(this,"data")),this._packer.on("end",this.emit.bind(this,"end")),this._parser.on("close",this._handleClose.bind(this)),this._packer.on("error",this.emit.bind(this,"error"))};d.inherits(i,e),i.sync=h,i.prototype.pack=function(){return this.data&&this.data.length?process.nextTick((function(){this._packer.pack(this.data,this.width,this.height,this.gamma)}).bind(this)):this.emit("error","No data provided"),this},i.prototype.parse=function(a,b){if(b){let a,c;a=(function(a){this.removeListener("error",c),this.data=a,b(null,this)}).bind(this),c=(function(c){this.removeListener("parsed",a),b(c,null)}).bind(this),this.once("parsed",a),this.once("error",c)}return this.end(a),this},i.prototype.write=function(a){return this._parser.write(a),!0},i.prototype.end=function(a){this._parser.end(a)},i.prototype._metadata=function(a){this.width=a.width,this.height=a.height,this.emit("metadata",a)},i.prototype._gamma=function(a){this.gamma=a},i.prototype._handleClose=function(){this._parser.writable||this._packer.readable||this.emit("close")},i.bitblt=function(a,b,c,d,e,f,g,h){if(d|=0,e|=0,f|=0,g|=0,h|=0,(c|=0)>a.width||d>a.height||c+e>a.width||d+f>a.height)throw Error("bitblt reading outside image");if(g>b.width||h>b.height||g+e>b.width||h+f>b.height)throw Error("bitblt writing outside image");for(let i=0;i<f;i++)a.data.copy(b.data,(h+i)*b.width+g<<2,(d+i)*a.width+c<<2,(d+i)*a.width+c+e<<2)},i.prototype.bitblt=function(a,b,c,d,e,f,g){return i.bitblt(this,a,b,c,d,e,f,g),this},i.adjustGamma=function(a){if(a.gamma){for(let b=0;b<a.height;b++)for(let c=0;c<a.width;c++){let d=a.width*b+c<<2;for(let b=0;b<3;b++){let c=a.data[d+b]/255;c=Math.pow(c,1/2.2/a.gamma),a.data[d+b]=Math.round(255*c)}}a.gamma=0}},i.prototype.adjustGamma=function(){i.adjustGamma(this)}},42516:(a,b,c)=>{"use strict";let d=c(81769),e=c(27734);b.process=function(a,b){let c=[],f=new d(a);return new e(b,{read:f.read.bind(f),write:function(a){c.push(a)},complete:function(){}}).start(),f.process(),Buffer.concat(c)}},43894:a=>{"use strict";let b=[];for(let a=0;a<256;a++){let c=a;for(let a=0;a<8;a++)1&c?c=0xedb88320^c>>>1:c>>>=1;b[a]=c}let c=a.exports=function(){this._crc=-1};c.prototype.write=function(a){for(let c=0;c<a.length;c++)this._crc=b[(this._crc^a[c])&255]^this._crc>>>8;return!0},c.prototype.crc32=function(){return -1^this._crc},c.crc32=function(a){let c=-1;for(let d=0;d<a.length;d++)c=b[(c^a[d])&255]^c>>>8;return -1^c}},46506:(a,b,c)=>{let d=c(51631),e=c(6334),f=c(26716),g=c(32767),h=c(7098),i=c(82413),j=c(3615),k=c(84879);function l(a){return unescape(encodeURIComponent(a)).length}function m(a,b,c){let d,e=[];for(;null!==(d=a.exec(c));)e.push({data:d[0],index:d.index,mode:b,length:d[0].length});return e}function n(a){let b,c,e=m(i.NUMERIC,d.NUMERIC,a),f=m(i.ALPHANUMERIC,d.ALPHANUMERIC,a);return j.isKanjiModeEnabled()?(b=m(i.BYTE,d.BYTE,a),c=m(i.KANJI,d.KANJI,a)):(b=m(i.BYTE_KANJI,d.BYTE,a),c=[]),e.concat(f,b,c).sort(function(a,b){return a.index-b.index}).map(function(a){return{data:a.data,mode:a.mode,length:a.length}})}function o(a,b){switch(b){case d.NUMERIC:return e.getBitsLength(a);case d.ALPHANUMERIC:return f.getBitsLength(a);case d.KANJI:return h.getBitsLength(a);case d.BYTE:return g.getBitsLength(a)}}function p(a,b){let c,i=d.getBestModeForData(a);if((c=d.from(b,i))!==d.BYTE&&c.bit<i.bit)throw Error('"'+a+'" cannot be encoded with mode '+d.toString(c)+".\n Suggested mode is: "+d.toString(i));switch(c===d.KANJI&&!j.isKanjiModeEnabled()&&(c=d.BYTE),c){case d.NUMERIC:return new e(a);case d.ALPHANUMERIC:return new f(a);case d.KANJI:return new h(a);case d.BYTE:return new g(a)}}b.fromArray=function(a){return a.reduce(function(a,b){return"string"==typeof b?a.push(p(b,null)):b.data&&a.push(p(b.data,b.mode)),a},[])},b.fromString=function(a,c){let e=function(a,b){let c={},e={start:{}},f=["start"];for(let g=0;g<a.length;g++){let h=a[g],i=[];for(let a=0;a<h.length;a++){let j=h[a],k=""+g+a;i.push(k),c[k]={node:j,lastCount:0},e[k]={};for(let a=0;a<f.length;a++){let g=f[a];c[g]&&c[g].node.mode===j.mode?(e[g][k]=o(c[g].lastCount+j.length,j.mode)-o(c[g].lastCount,j.mode),c[g].lastCount+=j.length):(c[g]&&(c[g].lastCount=j.length),e[g][k]=o(j.length,j.mode)+4+d.getCharCountIndicator(j.mode,b))}}f=i}for(let a=0;a<f.length;a++)e[f[a]].end=0;return{map:e,table:c}}(function(a){let b=[];for(let c=0;c<a.length;c++){let e=a[c];switch(e.mode){case d.NUMERIC:b.push([e,{data:e.data,mode:d.ALPHANUMERIC,length:e.length},{data:e.data,mode:d.BYTE,length:e.length}]);break;case d.ALPHANUMERIC:b.push([e,{data:e.data,mode:d.BYTE,length:e.length}]);break;case d.KANJI:b.push([e,{data:e.data,mode:d.BYTE,length:l(e.data)}]);break;case d.BYTE:b.push([{data:e.data,mode:d.BYTE,length:l(e.data)}])}}return b}(n(a,j.isKanjiModeEnabled())),c),f=k.find_path(e.map,"start","end"),g=[];for(let a=1;a<f.length-1;a++)g.push(e.table[f[a]].node);return b.fromArray(g.reduce(function(a,b){let c=a.length-1>=0?a[a.length-1]:null;return c&&c.mode===b.mode?a[a.length-1].data+=b.data:a.push(b),a},[]))},b.rawSplit=function(a){return b.fromArray(n(a,j.isKanjiModeEnabled()))}},46759:(a,b,c)=>{let d=c(3615).getSymbolSize;b.getPositions=function(a){let b=d(a);return[[0,0],[b-7,0],[0,b-7]]}},49149:(a,b,c)=>{"use strict";let d=c(28354),e=c(27910),f=c(67269),g=c(98052),h=a.exports=function(a){e.call(this),this._packer=new g(a||{}),this._deflate=this._packer.createDeflate(),this.readable=!0};d.inherits(h,e),h.prototype.pack=function(a,b,c,d){this.emit("data",Buffer.from(f.PNG_SIGNATURE)),this.emit("data",this._packer.packIHDR(b,c)),d&&this.emit("data",this._packer.packGAMA(d));let e=this._packer.filterData(a,b,c);this._deflate.on("error",this.emit.bind(this,"error")),this._deflate.on("data",(function(a){this.emit("data",this._packer.packIDAT(a))}).bind(this)),this._deflate.on("end",(function(){this.emit("data",this._packer.packIEND()),this.emit("end")}).bind(this)),this._deflate.end(e)}},49840:(a,b,c)=>{"use strict";let d=c(28354),e=c(57949),f=c(27734),g=a.exports=function(a){e.call(this);let b=[],c=this;this._filter=new f(a,{read:this.read.bind(this),write:function(a){b.push(a)},complete:function(){c.emit("complete",Buffer.concat(b))}}),this._filter.start()};d.inherits(g,e)},51631:(a,b,c)=>{let d=c(85171),e=c(82413);b.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},b.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},b.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},b.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},b.MIXED={bit:-1},b.getCharCountIndicator=function(a,b){if(!a.ccBits)throw Error("Invalid mode: "+a);if(!d.isValid(b))throw Error("Invalid version: "+b);return b>=1&&b<10?a.ccBits[0]:b<27?a.ccBits[1]:a.ccBits[2]},b.getBestModeForData=function(a){return e.testNumeric(a)?b.NUMERIC:e.testAlphanumeric(a)?b.ALPHANUMERIC:e.testKanji(a)?b.KANJI:b.BYTE},b.toString=function(a){if(a&&a.id)return a.id;throw Error("Invalid mode")},b.isValid=function(a){return a&&a.bit&&a.ccBits},b.from=function(a,c){if(b.isValid(a))return a;try{if("string"!=typeof a)throw Error("Param is not a string");switch(a.toLowerCase()){case"numeric":return b.NUMERIC;case"alphanumeric":return b.ALPHANUMERIC;case"kanji":return b.KANJI;case"byte":return b.BYTE;default:throw Error("Unknown mode: "+a)}}catch(a){return c}}},51888:(a,b)=>{let c=new Uint8Array(512),d=new Uint8Array(256),e=1;for(let a=0;a<255;a++)c[a]=e,d[e]=a,256&(e<<=1)&&(e^=285);for(let a=255;a<512;a++)c[a]=c[a-255];b.log=function(a){if(a<1)throw Error("log("+a+")");return d[a]},b.exp=function(a){return c[a]},b.mul=function(a,b){return 0===a||0===b?0:c[d[a]+d[b]]}},53300:(a,b,c)=>{let d=c(99127);b.render=function(a,b,c){var e;let f=c,g=b;void 0!==f||b&&b.getContext||(f=b,b=void 0),b||(g=function(){try{return document.createElement("canvas")}catch(a){throw Error("You need to specify a canvas element")}}()),f=d.getOptions(f);let h=d.getImageWidth(a.modules.size,f),i=g.getContext("2d"),j=i.createImageData(h,h);return d.qrToImageData(j.data,a,f),e=g,i.clearRect(0,0,e.width,e.height),e.style||(e.style={}),e.height=h,e.width=h,e.style.height=h+"px",e.style.width=h+"px",i.putImageData(j,0,0),g},b.renderToDataURL=function(a,c,d){let e=d;void 0!==e||c&&c.getContext||(e=c,c=void 0),e||(e={});let f=b.render(a,c,e),g=e.type||"image/png",h=e.rendererOpts||{};return f.toDataURL(g,h.quality)}},55211:a=>{"use strict";a.exports=function(a,b,c){let d=a+b-c,e=Math.abs(d-a),f=Math.abs(d-b),g=Math.abs(d-c);return e<=f&&e<=g?a:f<=g?b:c}},57949:(a,b,c)=>{"use strict";let d=c(28354),e=c(27910),f=a.exports=function(){e.call(this),this._buffers=[],this._buffered=0,this._reads=[],this._paused=!1,this._encoding="utf8",this.writable=!0};d.inherits(f,e),f.prototype.read=function(a,b){this._reads.push({length:Math.abs(a),allowLess:a<0,func:b}),process.nextTick((function(){this._process(),this._paused&&this._reads&&this._reads.length>0&&(this._paused=!1,this.emit("drain"))}).bind(this))},f.prototype.write=function(a,b){let c;return this.writable?(c=Buffer.isBuffer(a)?a:Buffer.from(a,b||this._encoding),this._buffers.push(c),this._buffered+=c.length,this._process(),this._reads&&0===this._reads.length&&(this._paused=!0),this.writable&&!this._paused):(this.emit("error",Error("Stream not writable")),!1)},f.prototype.end=function(a,b){a&&this.write(a,b),this.writable=!1,this._buffers&&(0===this._buffers.length?this._end():(this._buffers.push(null),this._process()))},f.prototype.destroySoon=f.prototype.end,f.prototype._end=function(){this._reads.length>0&&this.emit("error",Error("Unexpected end of input")),this.destroy()},f.prototype.destroy=function(){this._buffers&&(this.writable=!1,this._reads=null,this._buffers=null,this.emit("close"))},f.prototype._processReadAllowingLess=function(a){this._reads.shift();let b=this._buffers[0];b.length>a.length?(this._buffered-=a.length,this._buffers[0]=b.slice(a.length),a.func.call(this,b.slice(0,a.length))):(this._buffered-=b.length,this._buffers.shift(),a.func.call(this,b))},f.prototype._processRead=function(a){this._reads.shift();let b=0,c=0,d=Buffer.alloc(a.length);for(;b<a.length;){let e=this._buffers[c++],f=Math.min(e.length,a.length-b);e.copy(d,b,0,f),b+=f,f!==e.length&&(this._buffers[--c]=e.slice(f))}c>0&&this._buffers.splice(0,c),this._buffered-=a.length,a.func.call(this,d)},f.prototype._process=function(){try{for(;this._buffered>0&&this._reads&&this._reads.length>0;){let a=this._reads[0];if(a.allowLess)this._processReadAllowingLess(a);else if(this._buffered>=a.length)this._processRead(a);else break}this._buffers&&!this.writable&&this._end()}catch(a){this.emit("error",a)}}},58879:(a,b,c)=>{"use strict";let d=c(9709),e=c(80706);b.read=function(a,b){return d(a,b||{})},b.write=function(a,b){return e(a,b)}},59105:(a,b)=>{let c="\x1b[37m",d="\x1b[30m",e="\x1b[0m",f="\x1b[47m"+d,g="\x1b[40m"+c,h=function(a,b,c,d){let e=b+1;return c>=e||d>=e||d<-1||c<-1?"0":c>=b||d>=b||d<0||c<0?"1":a[d*b+c]?"2":"1"},i=function(a,b,c,d){return h(a,b,c,d)+h(a,b,c,d+1)};b.render=function(a,b,h){var j,k;let l=a.modules.size,m=a.modules.data,n=!!(b&&b.inverse),o=b&&b.inverse?g:f,p={"00":e+" "+o,"01":e+(j=n?d:c)+"▄"+o,"02":e+(k=n?c:d)+"▄"+o,10:e+j+"▀"+o,11:" ",12:"▄",20:e+k+"▀"+o,21:"▀",22:"█"},q=e+"\n"+o,r=o;for(let a=-1;a<l+1;a+=2){for(let b=-1;b<l;b++)r+=p[i(m,l,b,a)];r+=p[i(m,l,l,a)]+q}return r+=e,"function"==typeof h&&h(null,r),r}},59725:(a,b)=>{"use strict";let c=[{x:[0],y:[0]},{x:[4],y:[0]},{x:[0,4],y:[4]},{x:[2,6],y:[0,4]},{x:[0,2,4,6],y:[2,6]},{x:[1,3,5,7],y:[0,2,4,6]},{x:[0,1,2,3,4,5,6,7],y:[1,3,5,7]}];b.getImagePasses=function(a,b){let d=[],e=a%8,f=b%8,g=(a-e)/8,h=(b-f)/8;for(let a=0;a<c.length;a++){let b=c[a],i=g*b.x.length,j=h*b.y.length;for(let a=0;a<b.x.length;a++)if(b.x[a]<e)i++;else break;for(let a=0;a<b.y.length;a++)if(b.y[a]<f)j++;else break;i>0&&j>0&&d.push({width:i,height:j,index:a})}return d},b.getInterlaceIterator=function(a){return function(b,d,e){let f=b%c[e].x.length,g=(b-f)/c[e].x.length*8+c[e].x[f],h=d%c[e].y.length;return 4*g+((d-h)/c[e].y.length*8+c[e].y[h])*a*4}}},65276:(a,b,c)=>{b.render=c(9353).render,b.renderToFile=function(a,d,e,f){void 0===f&&(f=e,e=void 0);let g=c(29021),h=b.render(d,e);g.writeFile(a,'<?xml version="1.0" encoding="utf-8"?><!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">'+h,f)}},65966:a=>{a.exports=function(){return"function"==typeof Promise&&Promise.prototype&&Promise.prototype.then}},67269:a=>{"use strict";a.exports={PNG_SIGNATURE:[137,80,78,71,13,10,26,10],TYPE_IHDR:0x49484452,TYPE_IEND:0x49454e44,TYPE_IDAT:0x49444154,TYPE_PLTE:0x504c5445,TYPE_tRNS:0x74524e53,TYPE_gAMA:0x67414d41,COLORTYPE_GRAYSCALE:0,COLORTYPE_PALETTE:1,COLORTYPE_COLOR:2,COLORTYPE_ALPHA:4,COLORTYPE_PALETTE_COLOR:3,COLORTYPE_COLOR_ALPHA:6,COLORTYPE_TO_BPP_MAP:{0:1,2:3,3:1,4:2,6:4},GAMMA_DIVISION:1e5}},71479:(a,b,c)=>{let d=c(26794);function e(a){this.genPoly=void 0,this.degree=a,this.degree&&this.initialize(this.degree)}e.prototype.initialize=function(a){this.degree=a,this.genPoly=d.generateECPolynomial(this.degree)},e.prototype.encode=function(a){if(!this.genPoly)throw Error("Encoder not initialized");let b=new Uint8Array(a.length+this.degree);b.set(a);let c=d.mod(b,this.genPoly),e=this.degree-c.length;if(e>0){let a=new Uint8Array(this.degree);return a.set(c,e),a}return c},a.exports=e},72240:(a,b,c)=>{let d=c(3615).getSymbolSize;b.getRowColCoords=function(a){if(1===a)return[];let b=Math.floor(a/7)+2,c=d(a),e=145===c?26:2*Math.ceil((c-13)/(2*b-2)),f=[c-7];for(let a=1;a<b-1;a++)f[a]=f[a-1]-e;return f.push(6),f.reverse()},b.getPositions=function(a){let c=[],d=b.getRowColCoords(a),e=d.length;for(let a=0;a<e;a++)for(let b=0;b<e;b++)(0!==a||0!==b)&&(0!==a||b!==e-1)&&(a!==e-1||0!==b)&&c.push([d[a],d[b]]);return c}},76188:(a,b,c)=>{let d=c(3615),e=d.getBCHDigit(1335);b.getEncodedBits=function(a,b){let c=a.bit<<3|b,f=c<<10;for(;d.getBCHDigit(f)-e>=0;)f^=1335<<d.getBCHDigit(f)-e;return(c<<10|f)^21522}},80183:(a,b,c)=>{"use strict";let d=c(12412).ok,e=c(74075),f=c(28354),g=c(79428).kMaxLength;function h(a){if(!(this instanceof h))return new h(a);a&&a.chunkSize<e.Z_MIN_CHUNK&&(a.chunkSize=e.Z_MIN_CHUNK),e.Inflate.call(this,a),this._offset=void 0===this._offset?this._outOffset:this._offset,this._buffer=this._buffer||this._outBuffer,a&&null!=a.maxLength&&(this._maxLength=a.maxLength)}function i(a,b){b&&process.nextTick(b),a._handle&&(a._handle.close(),a._handle=null)}function j(a,b){var c=new h(b),d=a;if("string"==typeof d&&(d=Buffer.from(d)),!(d instanceof Buffer))throw TypeError("Not a string or buffer");let f=c._finishFlushFlag;return null==f&&(f=e.Z_FINISH),c._processChunk(d,f)}h.prototype._processChunk=function(a,b,c){let f,h;if("function"==typeof c)return e.Inflate._processChunk.call(this,a,b,c);let j=this,k=a&&a.length,l=this._chunkSize-this._offset,m=this._maxLength,n=0,o=[],p=0;this.on("error",function(a){f=a}),d(this._handle,"zlib binding closed");do h=(h=this._handle.writeSync(b,a,n,k,this._buffer,this._offset,l))||this._writeState;while(!this._hadError&&function(a,b){if(j._hadError)return;let c=l-b;if(d(c>=0,"have should not go down"),c>0){let a=j._buffer.slice(j._offset,j._offset+c);if(j._offset+=c,a.length>m&&(a=a.slice(0,m)),o.push(a),p+=a.length,0==(m-=a.length))return!1}return(0===b||j._offset>=j._chunkSize)&&(l=j._chunkSize,j._offset=0,j._buffer=Buffer.allocUnsafe(j._chunkSize)),0===b&&(n+=k-a,k=a,!0)}(h[0],h[1]));if(this._hadError)throw f;if(p>=g)throw i(this),RangeError("Cannot create final Buffer. It would be larger than 0x"+g.toString(16)+" bytes");let q=Buffer.concat(o,p);return i(this),q},f.inherits(h,e.Inflate),a.exports=b=j,b.Inflate=h,b.createInflate=function(a){return new h(a)},b.inflateSync=j},80706:(a,b,c)=>{"use strict";let d=!0,e=c(74075);e.deflateSync||(d=!1);let f=c(67269),g=c(98052);a.exports=function(a,b){if(!d)throw Error("To use the sync capability of this library in old node versions, please pin pngjs to v2.3.0");let c=new g(b||{}),h=[];h.push(Buffer.from(f.PNG_SIGNATURE)),h.push(c.packIHDR(a.width,a.height)),a.gamma&&h.push(c.packGAMA(a.gamma));let i=c.filterData(a.data,a.width,a.height),j=e.deflateSync(i,c.getDeflateOptions());if(i=null,!j||!j.length)throw Error("bad png - invalid compressed data response");return h.push(c.packIDAT(j)),h.push(c.packIEND()),Buffer.concat(h)}},80931:a=>{function b(a){if(!a||a<1)throw Error("BitMatrix size must be defined and greater than 0");this.size=a,this.data=new Uint8Array(a*a),this.reservedBit=new Uint8Array(a*a)}b.prototype.set=function(a,b,c,d){let e=a*this.size+b;this.data[e]=c,d&&(this.reservedBit[e]=!0)},b.prototype.get=function(a,b){return this.data[a*this.size+b]},b.prototype.xor=function(a,b,c){this.data[a*this.size+b]^=c},b.prototype.isReserved=function(a,b){return this.reservedBit[a*this.size+b]},a.exports=b},81769:a=>{"use strict";let b=a.exports=function(a){this._buffer=a,this._reads=[]};b.prototype.read=function(a,b){this._reads.push({length:Math.abs(a),allowLess:a<0,func:b})},b.prototype.process=function(){for(;this._reads.length>0&&this._buffer.length;){let a=this._reads[0];if(this._buffer.length&&(this._buffer.length>=a.length||a.allowLess)){this._reads.shift();let b=this._buffer;this._buffer=b.slice(a.length),a.func.call(this,b.slice(0,a.length))}else break}return this._reads.length>0?Error("There are some read requests waitng on finished stream"):this._buffer.length>0?Error("unrecognised content at end of stream"):void 0}},82413:(a,b)=>{let c="[0-9]+",d="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+",e="(?:(?![A-Z0-9 $%*+\\-./:]|"+(d=d.replace(/u/g,"\\u"))+")(?:.|[\r\n]))+";b.KANJI=RegExp(d,"g"),b.BYTE_KANJI=RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),b.BYTE=RegExp(e,"g"),b.NUMERIC=RegExp(c,"g"),b.ALPHANUMERIC=RegExp("[A-Z $%*+\\-./:]+","g");let f=RegExp("^"+d+"$"),g=RegExp("^"+c+"$"),h=RegExp("^[A-Z0-9 $%*+\\-./:]+$");b.testKanji=function(a){return f.test(a)},b.testNumeric=function(a){return g.test(a)},b.testAlphanumeric=function(a){return h.test(a)}},83340:(a,b,c)=>{let d=c(86531),e=c(59105);b.render=function(a,b,c){return b&&b.small?e.render(a,b,c):d.render(a,b,c)}},83670:a=>{"use strict";a.exports=function(a,b){let c=b.depth,d=b.width,e=b.height,f=b.colorType,g=b.transColor,h=b.palette,i=a;return 3===f?!function(a,b,c,d,e){let f=0;for(let g=0;g<d;g++)for(let d=0;d<c;d++){let c=e[a[f]];if(!c)throw Error("index "+a[f]+" not in palette");for(let a=0;a<4;a++)b[f+a]=c[a];f+=4}}(a,i,d,e,h):(g&&function(a,b,c,d,e){let f=0;for(let g=0;g<d;g++)for(let d=0;d<c;d++){let c=!1;if(1===e.length?e[0]===a[f]&&(c=!0):e[0]===a[f]&&e[1]===a[f+1]&&e[2]===a[f+2]&&(c=!0),c)for(let a=0;a<4;a++)b[f+a]=0;f+=4}}(a,i,d,e,g),8!==c&&(16===c&&(i=Buffer.alloc(d*e*4)),!function(a,b,c,d,e){let f=Math.pow(2,e)-1,g=0;for(let e=0;e<d;e++)for(let d=0;d<c;d++){for(let c=0;c<4;c++)b[g+c]=Math.floor(255*a[g+c]/f+.5);g+=4}}(a,i,d,e,c))),i}},84879:a=>{"use strict";var b={single_source_shortest_paths:function(a,c,d){var e,f,g,h,i,j,k,l={},m={};m[c]=0;var n=b.PriorityQueue.make();for(n.push(c,0);!n.empty();)for(g in f=(e=n.pop()).value,h=e.cost,i=a[f]||{})i.hasOwnProperty(g)&&(j=h+i[g],k=m[g],(void 0===m[g]||k>j)&&(m[g]=j,n.push(g,j),l[g]=f));if(void 0!==d&&void 0===m[d])throw Error("Could not find a path from "+c+" to "+d+".");return l},extract_shortest_path_from_predecessor_list:function(a,b){for(var c=[],d=b;d;)c.push(d),a[d],d=a[d];return c.reverse(),c},find_path:function(a,c,d){var e=b.single_source_shortest_paths(a,c,d);return b.extract_shortest_path_from_predecessor_list(e,d)},PriorityQueue:{make:function(a){var c,d=b.PriorityQueue,e={};for(c in a=a||{},d)d.hasOwnProperty(c)&&(e[c]=d[c]);return e.queue=[],e.sorter=a.sorter||d.default_sorter,e},default_sorter:function(a,b){return a.cost-b.cost},push:function(a,b){this.queue.push({value:a,cost:b}),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return 0===this.queue.length}}};a.exports=b},85171:(a,b)=>{b.isValid=function(a){return!isNaN(a)&&a>=1&&a<=40}},86531:(a,b)=>{b.render=function(a,b,c){let d=a.modules.size,e=a.modules.data,f="\x1b[47m  \x1b[0m",g="",h=Array(d+3).join(f),i=[,,].join(f);g+=h+"\n";for(let a=0;a<d;++a){g+=f;for(let b=0;b<d;b++)g+=e[a*d+b]?"\x1b[40m  \x1b[0m":f;g+=i+"\n"}return g+=h+"\n","function"==typeof c&&c(null,g),g}},92858:(a,b,c)=>{"use strict";let d=c(59725),e=[function(){},function(a,b,c,d){if(d===b.length)throw Error("Ran out of data");let e=b[d];a[c]=e,a[c+1]=e,a[c+2]=e,a[c+3]=255},function(a,b,c,d){if(d+1>=b.length)throw Error("Ran out of data");let e=b[d];a[c]=e,a[c+1]=e,a[c+2]=e,a[c+3]=b[d+1]},function(a,b,c,d){if(d+2>=b.length)throw Error("Ran out of data");a[c]=b[d],a[c+1]=b[d+1],a[c+2]=b[d+2],a[c+3]=255},function(a,b,c,d){if(d+3>=b.length)throw Error("Ran out of data");a[c]=b[d],a[c+1]=b[d+1],a[c+2]=b[d+2],a[c+3]=b[d+3]}],f=[function(){},function(a,b,c,d){let e=b[0];a[c]=e,a[c+1]=e,a[c+2]=e,a[c+3]=d},function(a,b,c){let d=b[0];a[c]=d,a[c+1]=d,a[c+2]=d,a[c+3]=b[1]},function(a,b,c,d){a[c]=b[0],a[c+1]=b[1],a[c+2]=b[2],a[c+3]=d},function(a,b,c){a[c]=b[0],a[c+1]=b[1],a[c+2]=b[2],a[c+3]=b[3]}];b.dataToBitMap=function(a,b){let c,g,h,i,j,k,l=b.width,m=b.height,n=b.depth,o=b.bpp,p=b.interlace;8!==n&&(c=[],g=0,h={get:function(b){for(;c.length<b;)!function(){let b,d,e,f;if(g===a.length)throw Error("Ran out of data");let h=a[g];switch(g++,n){default:throw Error("unrecognised depth");case 16:e=a[g],g++,c.push((h<<8)+e);break;case 4:e=15&h,f=h>>4,c.push(f,e);break;case 2:b=3&h,d=h>>2&3,e=h>>4&3,f=h>>6&3,c.push(f,e,d,b);break;case 1:b=h>>4&1,d=h>>5&1,e=h>>6&1,f=h>>7&1,c.push(f,e,d,b,h>>3&1,h>>2&1,h>>1&1,1&h)}}();let d=c.slice(0,b);return c=c.slice(b),d},resetAfterLine:function(){c.length=0},end:function(){if(g!==a.length)throw Error("extra data found")}}),i=n<=8?Buffer.alloc(l*m*4):new Uint16Array(l*m*4);let q=Math.pow(2,n)-1,r=0;if(p)j=d.getImagePasses(l,m),k=d.getInterlaceIterator(l,m);else{let a=0;k=function(){let b=a;return a+=4,b},j=[{width:l,height:m}]}for(let b=0;b<j.length;b++)8===n?r=function(a,b,c,d,f,g){let h=a.width,i=a.height,j=a.index;for(let a=0;a<i;a++)for(let i=0;i<h;i++){let h=c(i,a,j);e[d](b,f,h,g),g+=d}return g}(j[b],i,k,o,a,r):function(a,b,c,d,e,g){let h=a.width,i=a.height,j=a.index;for(let a=0;a<i;a++){for(let i=0;i<h;i++){let h=e.get(d),k=c(i,a,j);f[d](b,h,k,g)}e.resetAfterLine()}}(j[b],i,k,o,h,q);if(8===n){if(r!==a.length)throw Error("extra data found")}else h.end();return i}},93326:(a,b,c)=>{let d=c(3615),e=c(24566),f=c(11884),g=c(80931),h=c(72240),i=c(46759),j=c(14335),k=c(16419),l=c(71479),m=c(25010),n=c(76188),o=c(51631),p=c(46506);function q(a,b,c){let d,e,f=a.size,g=n.getEncodedBits(b,c);for(d=0;d<15;d++)e=(g>>d&1)==1,d<6?a.set(d,8,e,!0):d<8?a.set(d+1,8,e,!0):a.set(f-15+d,8,e,!0),d<8?a.set(8,f-d-1,e,!0):d<9?a.set(8,15-d-1+1,e,!0):a.set(8,15-d-1,e,!0);a.set(f-8,8,1,!0)}b.create=function(a,b){let c,n;if(void 0===a||""===a)throw Error("No input text");let r=e.M;return void 0!==b&&(r=e.from(b.errorCorrectionLevel,e.M),c=m.from(b.version),n=j.from(b.maskPattern),b.toSJISFunc&&d.setToSJISFunction(b.toSJISFunc)),function(a,b,c,e){let n;if(Array.isArray(a))n=p.fromArray(a);else if("string"==typeof a){let d=b;if(!d){let b=p.rawSplit(a);d=m.getBestVersionForData(b,c)}n=p.fromString(a,d||40)}else throw Error("Invalid data");let r=m.getBestVersionForData(n,c);if(!r)throw Error("The amount of data is too big to be stored in a QR Code");if(b){if(b<r)throw Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: "+r+".\n")}else b=r;let s=function(a,b,c){let e=new f;c.forEach(function(b){e.put(b.mode.bit,4),e.put(b.getLength(),o.getCharCountIndicator(b.mode,a)),b.write(e)});let g=(d.getSymbolTotalCodewords(a)-k.getTotalCodewordsCount(a,b))*8;for(e.getLengthInBits()+4<=g&&e.put(0,4);e.getLengthInBits()%8!=0;)e.putBit(0);let h=(g-e.getLengthInBits())/8;for(let a=0;a<h;a++)e.put(a%2?17:236,8);return function(a,b,c){let e,f,g=d.getSymbolTotalCodewords(b),h=g-k.getTotalCodewordsCount(b,c),i=k.getBlocksCount(b,c),j=g%i,m=i-j,n=Math.floor(g/i),o=Math.floor(h/i),p=o+1,q=n-o,r=new l(q),s=0,t=Array(i),u=Array(i),v=0,w=new Uint8Array(a.buffer);for(let a=0;a<i;a++){let b=a<m?o:p;t[a]=w.slice(s,s+b),u[a]=r.encode(t[a]),s+=b,v=Math.max(v,b)}let x=new Uint8Array(g),y=0;for(e=0;e<v;e++)for(f=0;f<i;f++)e<t[f].length&&(x[y++]=t[f][e]);for(e=0;e<q;e++)for(f=0;f<i;f++)x[y++]=u[f][e];return x}(e,a,b)}(b,c,n),t=new g(d.getSymbolSize(b));!function(a,b){let c=a.size,d=i.getPositions(b);for(let b=0;b<d.length;b++){let e=d[b][0],f=d[b][1];for(let b=-1;b<=7;b++)if(!(e+b<=-1)&&!(c<=e+b))for(let d=-1;d<=7;d++)f+d<=-1||c<=f+d||(b>=0&&b<=6&&(0===d||6===d)||d>=0&&d<=6&&(0===b||6===b)||b>=2&&b<=4&&d>=2&&d<=4?a.set(e+b,f+d,!0,!0):a.set(e+b,f+d,!1,!0))}}(t,b);let u=t.size;for(let a=8;a<u-8;a++){let b=a%2==0;t.set(a,6,b,!0),t.set(6,a,b,!0)}return!function(a,b){let c=h.getPositions(b);for(let b=0;b<c.length;b++){let d=c[b][0],e=c[b][1];for(let b=-2;b<=2;b++)for(let c=-2;c<=2;c++)-2===b||2===b||-2===c||2===c||0===b&&0===c?a.set(d+b,e+c,!0,!0):a.set(d+b,e+c,!1,!0)}}(t,b),q(t,c,0),b>=7&&function(a,b){let c,d,e,f=a.size,g=m.getEncodedBits(b);for(let b=0;b<18;b++)c=Math.floor(b/3),d=b%3+f-8-3,e=(g>>b&1)==1,a.set(c,d,e,!0),a.set(d,c,e,!0)}(t,b),!function(a,b){let c=a.size,d=-1,e=c-1,f=7,g=0;for(let h=c-1;h>0;h-=2)for(6===h&&h--;;){for(let c=0;c<2;c++)if(!a.isReserved(e,h-c)){let d=!1;g<b.length&&(d=(b[g]>>>f&1)==1),a.set(e,h-c,d),-1==--f&&(g++,f=7)}if((e+=d)<0||c<=e){e-=d,d=-d;break}}}(t,s),isNaN(e)&&(e=j.getBestMask(t,q.bind(null,t,c))),j.applyMask(e,t),q(t,c,e),{modules:t,version:b,errorCorrectionLevel:c,maskPattern:e,segments:n}}(a,c,r,n)}},94161:(a,b,c)=>{let d=c(29021),e=c(34447).O,f=c(99127);b.render=function(a,b){let c=f.getOptions(b),d=c.rendererOpts,g=f.getImageWidth(a.modules.size,c);d.width=g,d.height=g;let h=new e(d);return f.qrToImageData(h.data,a,c),h},b.renderToDataURL=function(a,c,d){void 0===d&&(d=c,c=void 0),b.renderToBuffer(a,c,function(a,b){a&&d(a);let c="data:image/png;base64,";c+=b.toString("base64"),d(null,c)})},b.renderToBuffer=function(a,c,d){void 0===d&&(d=c,c=void 0);let e=b.render(a,c),f=[];e.on("error",d),e.on("data",function(a){f.push(a)}),e.on("end",function(){d(null,Buffer.concat(f))}),e.pack()},b.renderToFile=function(a,c,e,f){void 0===f&&(f=e,e=void 0);let g=!1,h=(...a)=>{g||(g=!0,f.apply(null,a))},i=d.createWriteStream(a);i.on("error",h),i.on("close",h),b.renderToFileStream(i,c,e)},b.renderToFileStream=function(a,c,d){b.render(c,d).pack().pipe(a)}},94165:(a,b,c)=>{"use strict";let d=c(67269);a.exports=function(a,b,c,e){let f=-1!==[d.COLORTYPE_COLOR_ALPHA,d.COLORTYPE_ALPHA].indexOf(e.colorType);if(e.colorType===e.inputColorType){let b,c=(new DataView(b=new ArrayBuffer(2)).setInt16(0,256,!0),256!==new Int16Array(b)[0]);if(8===e.bitDepth||16===e.bitDepth&&c)return a}let g=16!==e.bitDepth?a:new Uint16Array(a.buffer),h=255,i=d.COLORTYPE_TO_BPP_MAP[e.inputColorType];4!==i||e.inputHasAlpha||(i=3);let j=d.COLORTYPE_TO_BPP_MAP[e.colorType];16===e.bitDepth&&(h=65535,j*=2);let k=Buffer.alloc(b*c*j),l=0,m=0,n=e.bgColor||{};void 0===n.red&&(n.red=h),void 0===n.green&&(n.green=h),void 0===n.blue&&(n.blue=h);for(let a=0;a<c;a++)for(let a=0;a<b;a++){let a=function(){let a,b,c,i=h;switch(e.inputColorType){case d.COLORTYPE_COLOR_ALPHA:i=g[l+3],a=g[l],b=g[l+1],c=g[l+2];break;case d.COLORTYPE_COLOR:a=g[l],b=g[l+1],c=g[l+2];break;case d.COLORTYPE_ALPHA:i=g[l+1],b=a=g[l],c=a;break;case d.COLORTYPE_GRAYSCALE:b=a=g[l],c=a;break;default:throw Error("input color type:"+e.inputColorType+" is not supported at present")}return e.inputHasAlpha&&!f&&(i/=h,a=Math.min(Math.max(Math.round((1-i)*n.red+i*a),0),h),b=Math.min(Math.max(Math.round((1-i)*n.green+i*b),0),h),c=Math.min(Math.max(Math.round((1-i)*n.blue+i*c),0),h)),{red:a,green:b,blue:c,alpha:i}}(g,l);switch(e.colorType){case d.COLORTYPE_COLOR_ALPHA:case d.COLORTYPE_COLOR:8===e.bitDepth?(k[m]=a.red,k[m+1]=a.green,k[m+2]=a.blue,f&&(k[m+3]=a.alpha)):(k.writeUInt16BE(a.red,m),k.writeUInt16BE(a.green,m+2),k.writeUInt16BE(a.blue,m+4),f&&k.writeUInt16BE(a.alpha,m+6));break;case d.COLORTYPE_ALPHA:case d.COLORTYPE_GRAYSCALE:{let b=(a.red+a.green+a.blue)/3;8===e.bitDepth?(k[m]=b,f&&(k[m+1]=a.alpha)):(k.writeUInt16BE(b,m),f&&k.writeUInt16BE(a.alpha,m+2));break}default:throw Error("unrecognised color Type "+e.colorType)}l+=i,m+=j}return k}},96277:(a,b,c)=>{"use strict";let d=c(67269),e=c(43894),f=a.exports=function(a,b){this._options=a,a.checkCRC=!1!==a.checkCRC,this._hasIHDR=!1,this._hasIEND=!1,this._emittedHeadersFinished=!1,this._palette=[],this._colorType=0,this._chunks={},this._chunks[d.TYPE_IHDR]=this._handleIHDR.bind(this),this._chunks[d.TYPE_IEND]=this._handleIEND.bind(this),this._chunks[d.TYPE_IDAT]=this._handleIDAT.bind(this),this._chunks[d.TYPE_PLTE]=this._handlePLTE.bind(this),this._chunks[d.TYPE_tRNS]=this._handleTRNS.bind(this),this._chunks[d.TYPE_gAMA]=this._handleGAMA.bind(this),this.read=b.read,this.error=b.error,this.metadata=b.metadata,this.gamma=b.gamma,this.transColor=b.transColor,this.palette=b.palette,this.parsed=b.parsed,this.inflateData=b.inflateData,this.finished=b.finished,this.simpleTransparency=b.simpleTransparency,this.headersFinished=b.headersFinished||function(){}};f.prototype.start=function(){this.read(d.PNG_SIGNATURE.length,this._parseSignature.bind(this))},f.prototype._parseSignature=function(a){let b=d.PNG_SIGNATURE;for(let c=0;c<b.length;c++)if(a[c]!==b[c])return void this.error(Error("Invalid file signature"));this.read(8,this._parseChunkBegin.bind(this))},f.prototype._parseChunkBegin=function(a){let b=a.readUInt32BE(0),c=a.readUInt32BE(4),f="";for(let b=4;b<8;b++)f+=String.fromCharCode(a[b]);let g=!!(32&a[4]);return this._hasIHDR||c===d.TYPE_IHDR?(this._crc=new e,this._crc.write(Buffer.from(f)),this._chunks[c])?this._chunks[c](b):g?void this.read(b+4,this._skipChunk.bind(this)):void this.error(Error("Unsupported critical chunk type "+f)):void this.error(Error("Expected IHDR on beggining"))},f.prototype._skipChunk=function(){this.read(8,this._parseChunkBegin.bind(this))},f.prototype._handleChunkEnd=function(){this.read(4,this._parseChunkEnd.bind(this))},f.prototype._parseChunkEnd=function(a){let b=a.readInt32BE(0),c=this._crc.crc32();this._options.checkCRC&&c!==b?this.error(Error("Crc error - "+b+" - "+c)):this._hasIEND||this.read(8,this._parseChunkBegin.bind(this))},f.prototype._handleIHDR=function(a){this.read(a,this._parseIHDR.bind(this))},f.prototype._parseIHDR=function(a){this._crc.write(a);let b=a.readUInt32BE(0),c=a.readUInt32BE(4),e=a[8],f=a[9],g=a[10],h=a[11],i=a[12];if(8!==e&&4!==e&&2!==e&&1!==e&&16!==e)return void this.error(Error("Unsupported bit depth "+e));if(!(f in d.COLORTYPE_TO_BPP_MAP))return void this.error(Error("Unsupported color type"));if(0!==g)return void this.error(Error("Unsupported compression method"));if(0!==h)return void this.error(Error("Unsupported filter method"));if(0!==i&&1!==i)return void this.error(Error("Unsupported interlace method"));this._colorType=f;let j=d.COLORTYPE_TO_BPP_MAP[this._colorType];this._hasIHDR=!0,this.metadata({width:b,height:c,depth:e,interlace:!!i,palette:!!(f&d.COLORTYPE_PALETTE),color:!!(f&d.COLORTYPE_COLOR),alpha:!!(f&d.COLORTYPE_ALPHA),bpp:j,colorType:f}),this._handleChunkEnd()},f.prototype._handlePLTE=function(a){this.read(a,this._parsePLTE.bind(this))},f.prototype._parsePLTE=function(a){this._crc.write(a);let b=Math.floor(a.length/3);for(let c=0;c<b;c++)this._palette.push([a[3*c],a[3*c+1],a[3*c+2],255]);this.palette(this._palette),this._handleChunkEnd()},f.prototype._handleTRNS=function(a){this.simpleTransparency(),this.read(a,this._parseTRNS.bind(this))},f.prototype._parseTRNS=function(a){if(this._crc.write(a),this._colorType===d.COLORTYPE_PALETTE_COLOR){if(0===this._palette.length)return void this.error(Error("Transparency chunk must be after palette"));if(a.length>this._palette.length)return void this.error(Error("More transparent colors than palette size"));for(let b=0;b<a.length;b++)this._palette[b][3]=a[b];this.palette(this._palette)}this._colorType===d.COLORTYPE_GRAYSCALE&&this.transColor([a.readUInt16BE(0)]),this._colorType===d.COLORTYPE_COLOR&&this.transColor([a.readUInt16BE(0),a.readUInt16BE(2),a.readUInt16BE(4)]),this._handleChunkEnd()},f.prototype._handleGAMA=function(a){this.read(a,this._parseGAMA.bind(this))},f.prototype._parseGAMA=function(a){this._crc.write(a),this.gamma(a.readUInt32BE(0)/d.GAMMA_DIVISION),this._handleChunkEnd()},f.prototype._handleIDAT=function(a){this._emittedHeadersFinished||(this._emittedHeadersFinished=!0,this.headersFinished()),this.read(-a,this._parseIDAT.bind(this,a))},f.prototype._parseIDAT=function(a,b){if(this._crc.write(b),this._colorType===d.COLORTYPE_PALETTE_COLOR&&0===this._palette.length)throw Error("Expected palette not found");this.inflateData(b);let c=a-b.length;c>0?this._handleIDAT(c):this._handleChunkEnd()},f.prototype._handleIEND=function(a){this.read(a,this._parseIEND.bind(this))},f.prototype._parseIEND=function(a){this._crc.write(a),this._hasIEND=!0,this._handleChunkEnd(),this.finished&&this.finished()}},98052:(a,b,c)=>{"use strict";let d=c(67269),e=c(43894),f=c(94165),g=c(31964),h=c(74075),i=a.exports=function(a){if(this._options=a,a.deflateChunkSize=a.deflateChunkSize||32768,a.deflateLevel=null!=a.deflateLevel?a.deflateLevel:9,a.deflateStrategy=null!=a.deflateStrategy?a.deflateStrategy:3,a.inputHasAlpha=null==a.inputHasAlpha||a.inputHasAlpha,a.deflateFactory=a.deflateFactory||h.createDeflate,a.bitDepth=a.bitDepth||8,a.colorType="number"==typeof a.colorType?a.colorType:d.COLORTYPE_COLOR_ALPHA,a.inputColorType="number"==typeof a.inputColorType?a.inputColorType:d.COLORTYPE_COLOR_ALPHA,-1===[d.COLORTYPE_GRAYSCALE,d.COLORTYPE_COLOR,d.COLORTYPE_COLOR_ALPHA,d.COLORTYPE_ALPHA].indexOf(a.colorType))throw Error("option color type:"+a.colorType+" is not supported at present");if(-1===[d.COLORTYPE_GRAYSCALE,d.COLORTYPE_COLOR,d.COLORTYPE_COLOR_ALPHA,d.COLORTYPE_ALPHA].indexOf(a.inputColorType))throw Error("option input color type:"+a.inputColorType+" is not supported at present");if(8!==a.bitDepth&&16!==a.bitDepth)throw Error("option bit depth:"+a.bitDepth+" is not supported at present")};i.prototype.getDeflateOptions=function(){return{chunkSize:this._options.deflateChunkSize,level:this._options.deflateLevel,strategy:this._options.deflateStrategy}},i.prototype.createDeflate=function(){return this._options.deflateFactory(this.getDeflateOptions())},i.prototype.filterData=function(a,b,c){let e=f(a,b,c,this._options),h=d.COLORTYPE_TO_BPP_MAP[this._options.colorType];return g(e,b,c,this._options,h)},i.prototype._packChunk=function(a,b){let c=b?b.length:0,d=Buffer.alloc(c+12);return d.writeUInt32BE(c,0),d.writeUInt32BE(a,4),b&&b.copy(d,8),d.writeInt32BE(e.crc32(d.slice(4,d.length-4)),d.length-4),d},i.prototype.packGAMA=function(a){let b=Buffer.alloc(4);return b.writeUInt32BE(Math.floor(a*d.GAMMA_DIVISION),0),this._packChunk(d.TYPE_gAMA,b)},i.prototype.packIHDR=function(a,b){let c=Buffer.alloc(13);return c.writeUInt32BE(a,0),c.writeUInt32BE(b,4),c[8]=this._options.bitDepth,c[9]=this._options.colorType,c[10]=0,c[11]=0,c[12]=0,this._packChunk(d.TYPE_IHDR,c)},i.prototype.packIDAT=function(a){return this._packChunk(d.TYPE_IDAT,a)},i.prototype.packIEND=function(){return this._packChunk(d.TYPE_IEND,null)}},99127:(a,b)=>{function c(a){if("number"==typeof a&&(a=a.toString()),"string"!=typeof a)throw Error("Color should be defined as hex string");let b=a.slice().replace("#","").split("");if(b.length<3||5===b.length||b.length>8)throw Error("Invalid hex color: "+a);(3===b.length||4===b.length)&&(b=Array.prototype.concat.apply([],b.map(function(a){return[a,a]}))),6===b.length&&b.push("F","F");let c=parseInt(b.join(""),16);return{r:c>>24&255,g:c>>16&255,b:c>>8&255,a:255&c,hex:"#"+b.slice(0,6).join("")}}b.getOptions=function(a){a||(a={}),a.color||(a.color={});let b=void 0===a.margin||null===a.margin||a.margin<0?4:a.margin,d=a.width&&a.width>=21?a.width:void 0,e=a.scale||4;return{width:d,scale:d?4:e,margin:b,color:{dark:c(a.color.dark||"#000000ff"),light:c(a.color.light||"#ffffffff")},type:a.type,rendererOpts:a.rendererOpts||{}}},b.getScale=function(a,b){return b.width&&b.width>=a+2*b.margin?b.width/(a+2*b.margin):b.scale},b.getImageWidth=function(a,c){let d=b.getScale(a,c);return Math.floor((a+2*c.margin)*d)},b.qrToImageData=function(a,c,d){let e=c.modules.size,f=c.modules.data,g=b.getScale(e,d),h=Math.floor((e+2*d.margin)*g),i=d.margin*g,j=[d.color.light,d.color.dark];for(let b=0;b<h;b++)for(let c=0;c<h;c++){let k=(b*h+c)*4,l=d.color.light;b>=i&&c>=i&&b<h-i&&c<h-i&&(l=j[+!!f[Math.floor((b-i)/g)*e+Math.floor((c-i)/g)]]),a[k++]=l.r,a[k++]=l.g,a[k++]=l.b,a[k]=l.a}}}};